// Copyright (c) 2011 The LevelDB Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file. See the AUTHORS file for names of contributors.

#include "leveldb/merge_operator.h"

namespace leveldb {

MergeOperator::~MergeOperator() = default;

bool MergeOperator::PartialMerge(const Slice& key, const Slice& left,
                                 const Slice& right,
                                 std::string* result) const {
  return false;
}

}  // namespace leveldb
