// Copyright (c) 2011 The LevelDB Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file. See the AUTHORS file for names of contributors.
//
// A MergeOperator folds merge operands recorded with DB::Merge or
// WriteBatch::Merge into the value of a key.

#ifndef STORAGE_LEVELDB_INCLUDE_MERGE_OPERATOR_H_
#define STORAGE_LEVELDB_INCLUDE_MERGE_OPERATOR_H_

#include <string>
#include <vector>

#include "leveldb/export.h"
#include "leveldb/slice.h"

namespace leveldb {

class LEVELDB_EXPORT MergeOperator {
 public:
  virtual ~MergeOperator();

  // The name of the operator.
  virtual const char* Name() const = 0;

  // Fold `operands` (oldest first) into `existing` (nullptr when the key has
  // no value underneath them) and store the result in *new_value.
  virtual bool FullMerge(const Slice& key, const Slice* existing,
                         const std::vector<std::string>& operands,
                         std::string* new_value) const = 0;

  // Optionally fold two adjacent operands, `left` older than `right`, into
  // one operand with the same effect.  Returns false if it cannot.
  virtual bool PartialMerge(const Slice& key, const Slice& left,
                            const Slice& right, std::string* result) const;
};

}  // namespace leveldb

#endif  // STORAGE_LEVELDB_INCLUDE_MERGE_OPERATOR_H_
