// Copyright (c) 2011 The LevelDB Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file. See the AUTHORS file for names of contributors.
//
// WriteBatch::rep_ :=
//    sequence: fixed64
//    count: fixed32
//    data: record[count]
// record :=
//    kTypeValue varstring varstring         |
//    kTypeDeletion varstring |
//    kTypeMerge varstring varstring |
//    kTypeRangeDeletion varstring varstring |    (begin, end)
//    kCFType* varint32 <the payload of the tag it mirrors>
// varstring :=
//    len: varint32
//    data: uint8[len]

#include "leveldb/write_batch.h"

#include "db/dbformat.h"
#include "db/memtable.h"
#include "db/write_batch_internal.h"
#include <map>
#include <set>

#include "leveldb/db.h"
#include "util/coding.h"

namespace leveldb {

// WriteBatch header has an 8-byte sequence number followed by a 4-byte count.
static const size_t kHeader = 12;

WriteBatch::WriteBatch() { Clear(); }

WriteBatch::~WriteBatch() = default;

WriteBatch::Handler::~Handler() = default;

void WriteBatch::Handler::DeleteRange(const Slice& begin, const Slice& end) {}

void WriteBatch::Handler::Merge(const Slice& key, const Slice& value) {}

void WriteBatch::Handler::PutCF(uint32_t cf, const Slice& key,
                                const Slice& value) {
  if (cf == 0) Put(key, value);
}

void WriteBatch::Handler::DeleteCF(uint32_t cf, const Slice& key) {
  if (cf == 0) Delete(key);
}

void WriteBatch::Handler::MergeCF(uint32_t cf, const Slice& key,
                                  const Slice& value) {
  if (cf == 0) Merge(key, value);
}

void WriteBatch::Handler::DeleteRangeCF(uint32_t cf, const Slice& begin,
                                        const Slice& end) {
  if (cf == 0) DeleteRange(begin, end);
}

void WriteBatch::Clear() {
  rep_.clear();
  rep_.resize(kHeader);
}

size_t WriteBatch::ApproximateSize() const { return rep_.size(); }

Status WriteBatch::Iterate(Handler* handler) const {
  Slice input(rep_);
  if (input.size() < kHeader) {
    return Status::Corruption("malformed WriteBatch (too small)");
  }

  input.remove_prefix(kHeader);
  Slice key, value;
  int found = 0;
  while (!input.empty()) {
    found++;
    char tag = input[0];
    input.remove_prefix(1);
    uint32_t cf = 0;
    if (tag >= kCFTagBase && tag <= kCFTypeRangeDeletion) {
      if (!GetVarint32(&input, &cf)) {
        return Status::Corruption("bad WriteBatch column family");
      }
      tag = static_cast<char>(tag - kCFTagBase);
    }
    switch (tag) {
      case kTypeValue:
        if (GetLengthPrefixedSlice(&input, &key) &&
            GetLengthPrefixedSlice(&input, &value)) {
          handler->PutCF(cf, key, value);
        } else {
          return Status::Corruption("bad WriteBatch Put");
        }
        break;
      case kTypeDeletion:
        if (GetLengthPrefixedSlice(&input, &key)) {
          handler->DeleteCF(cf, key);
        } else {
          return Status::Corruption("bad WriteBatch Delete");
        }
        break;
      case kTypeMerge:
        if (GetLengthPrefixedSlice(&input, &key) &&
            GetLengthPrefixedSlice(&input, &value)) {
          handler->MergeCF(cf, key, value);
        } else {
          return Status::Corruption("bad WriteBatch Merge");
        }
        break;
      case kTypeRangeDeletion:
        if (GetLengthPrefixedSlice(&input, &key) &&
            GetLengthPrefixedSlice(&input, &value)) {
          handler->DeleteRangeCF(cf, key, value);
        } else {
          return Status::Corruption("bad WriteBatch DeleteRange");
        }
        break;
      default:
        return Status::Corruption("unknown WriteBatch tag");
    }
  }
  if (found != WriteBatchInternal::Count(this)) {
    return Status::Corruption("WriteBatch has wrong count");
  } else {
    return Status::OK();
  }
}

int WriteBatchInternal::Count(const WriteBatch* b) {
  return DecodeFixed32(b->rep_.data() + 8);
}

void WriteBatchInternal::SetCount(WriteBatch* b, int n) {
  EncodeFixed32(&b->rep_[8], n);
}

SequenceNumber WriteBatchInternal::Sequence(const WriteBatch* b) {
  return SequenceNumber(DecodeFixed64(b->rep_.data()));
}

void WriteBatchInternal::SetSequence(WriteBatch* b, SequenceNumber seq) {
  EncodeFixed64(&b->rep_[0], seq);
}

void WriteBatch::Put(const Slice& key, const Slice& value) {
  WriteBatchInternal::SetCount(this, WriteBatchInternal::Count(this) + 1);
  rep_.push_back(static_cast<char>(kTypeValue));
  PutLengthPrefixedSlice(&rep_, key);
  PutLengthPrefixedSlice(&rep_, value);
}

void WriteBatch::Delete(const Slice& key) {
  WriteBatchInternal::SetCount(this, WriteBatchInternal::Count(this) + 1);
  rep_.push_back(static_cast<char>(kTypeDeletion));
  PutLengthPrefixedSlice(&rep_, key);
}

void WriteBatch::DeleteRange(const Slice& begin, const Slice& end) {
  WriteBatchInternal::SetCount(this, WriteBatchInternal::Count(this) + 1);
  rep_.push_back(static_cast<char>(kTypeRangeDeletion));
  PutLengthPrefixedSlice(&rep_, begin);
  PutLengthPrefixedSlice(&rep_, end);
}

void WriteBatch::Merge(const Slice& key, const Slice& value) {
  WriteBatchInternal::SetCount(this, WriteBatchInternal::Count(this) + 1);
  rep_.push_back(static_cast<char>(kTypeMerge));
  PutLengthPrefixedSlice(&rep_, key);
  PutLengthPrefixedSlice(&rep_, value);
}

namespace {
uint32_t FamilyId(ColumnFamilyHandle* family) {
  return family == nullptr ? 0 : family->GetID();
}
}  // namespace

void WriteBatch::Put(ColumnFamilyHandle* family, const Slice& key,
                     const Slice& value) {
  const uint32_t cf = FamilyId(family);
  if (cf == 0) return Put(key, value);
  WriteBatchInternal::SetCount(this, WriteBatchInternal::Count(this) + 1);
  rep_.push_back(static_cast<char>(kCFTypeValue));
  PutVarint32(&rep_, cf);
  PutLengthPrefixedSlice(&rep_, key);
  PutLengthPrefixedSlice(&rep_, value);
}

void WriteBatch::Delete(ColumnFamilyHandle* family, const Slice& key) {
  const uint32_t cf = FamilyId(family);
  if (cf == 0) return Delete(key);
  WriteBatchInternal::SetCount(this, WriteBatchInternal::Count(this) + 1);
  rep_.push_back(static_cast<char>(kCFTypeDeletion));
  PutVarint32(&rep_, cf);
  PutLengthPrefixedSlice(&rep_, key);
}

void WriteBatch::Merge(ColumnFamilyHandle* family, const Slice& key,
                       const Slice& value) {
  const uint32_t cf = FamilyId(family);
  if (cf == 0) return Merge(key, value);
  WriteBatchInternal::SetCount(this, WriteBatchInternal::Count(this) + 1);
  rep_.push_back(static_cast<char>(kCFTypeMerge));
  PutVarint32(&rep_, cf);
  PutLengthPrefixedSlice(&rep_, key);
  PutLengthPrefixedSlice(&rep_, value);
}

void WriteBatch::DeleteRange(ColumnFamilyHandle* family, const Slice& begin,
                             const Slice& end) {
  const uint32_t cf = FamilyId(family);
  if (cf == 0) return DeleteRange(begin, end);
  WriteBatchInternal::SetCount(this, WriteBatchInternal::Count(this) + 1);
  rep_.push_back(static_cast<char>(kCFTypeRangeDeletion));
  PutVarint32(&rep_, cf);
  PutLengthPrefixedSlice(&rep_, begin);
  PutLengthPrefixedSlice(&rep_, end);
}

void WriteBatch::Append(const WriteBatch& source) {
  WriteBatchInternal::Append(this, &source);
}

namespace {
// Routes each record to the memtable of its column family.  A family the
// map does not name (dropped, or already flushed past this log during
// recovery) is skipped, but still consumes its sequence number.
class MemTableInserter : public WriteBatch::Handler {
 public:
  SequenceNumber sequence_;
  const std::map<uint32_t, MemTable*>* mems_;

  MemTable* Find(uint32_t cf) const {
    auto it = mems_->find(cf);
    return it == mems_->end() ? nullptr : it->second;
  }
  void Add(uint32_t cf, ValueType type, const Slice& key, const Slice& value) {
    MemTable* mem = Find(cf);
    if (mem != nullptr) mem->Add(sequence_, type, key, value);
    sequence_++;
  }
  void Put(const Slice& key, const Slice& value) override {
    Add(0, kTypeValue, key, value);
  }
  void Delete(const Slice& key) override { Add(0, kTypeDeletion, key, Slice()); }
  void DeleteRange(const Slice& begin, const Slice& end) override {
    Add(0, kTypeRangeDeletion, begin, end);
  }
  void Merge(const Slice& key, const Slice& value) override {
    Add(0, kTypeMerge, key, value);
  }
  void PutCF(uint32_t cf, const Slice& key, const Slice& value) override {
    Add(cf, kTypeValue, key, value);
  }
  void DeleteCF(uint32_t cf, const Slice& key) override {
    Add(cf, kTypeDeletion, key, Slice());
  }
  void DeleteRangeCF(uint32_t cf, const Slice& begin, const Slice& end) override {
    Add(cf, kTypeRangeDeletion, begin, end);
  }
  void MergeCF(uint32_t cf, const Slice& key, const Slice& value) override {
    Add(cf, kTypeMerge, key, value);
  }
};

// Which families does the batch touch, and does any of them get an operand?
class BatchScanner : public WriteBatch::Handler {
 public:
  std::set<uint32_t> families;
  std::set<uint32_t> merges;
  void Put(const Slice& key, const Slice& value) override { families.insert(0); }
  void Delete(const Slice& key) override { families.insert(0); }
  void Merge(const Slice& key, const Slice& value) override {
    families.insert(0);
    merges.insert(0);
  }
  void DeleteRange(const Slice& b, const Slice& e) override { families.insert(0); }
  void PutCF(uint32_t cf, const Slice& k, const Slice& v) override { families.insert(cf); }
  void DeleteCF(uint32_t cf, const Slice& k) override { families.insert(cf); }
  void MergeCF(uint32_t cf, const Slice& k, const Slice& v) override {
    families.insert(cf);
    merges.insert(cf);
  }
  void DeleteRangeCF(uint32_t cf, const Slice& b, const Slice& e) override {
    families.insert(cf);
  }
};
}  // namespace

Status WriteBatchInternal::InsertInto(const WriteBatch* b,
                                      const std::map<uint32_t, MemTable*>& mems) {
  MemTableInserter inserter;
  inserter.sequence_ = WriteBatchInternal::Sequence(b);
  inserter.mems_ = &mems;
  return b->Iterate(&inserter);
}

Status WriteBatchInternal::InsertInto(const WriteBatch* b, MemTable* memtable) {
  std::map<uint32_t, MemTable*> mems{{0, memtable}};
  return InsertInto(b, mems);
}

void WriteBatchInternal::Scan(const WriteBatch* b, std::set<uint32_t>* families,
                              std::set<uint32_t>* merges) {
  BatchScanner scanner;
  b->Iterate(&scanner);
  if (families != nullptr) *families = std::move(scanner.families);
  if (merges != nullptr) *merges = std::move(scanner.merges);
}

void WriteBatchInternal::SetContents(WriteBatch* b, const Slice& contents) {
  assert(contents.size() >= kHeader);
  b->rep_.assign(contents.data(), contents.size());
}

void WriteBatchInternal::Append(WriteBatch* dst, const WriteBatch* src) {
  SetCount(dst, Count(dst) + Count(src));
  assert(src->rep_.size() >= kHeader);
  dst->rep_.append(src->rep_.data() + kHeader, src->rep_.size() - kHeader);
}

}  // namespace leveldb
