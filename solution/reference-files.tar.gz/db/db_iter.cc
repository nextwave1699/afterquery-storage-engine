// Copyright (c) 2011 The LevelDB Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file. See the AUTHORS file for names of contributors.

#include "db/db_iter.h"

#include "db/db_impl.h"
#include "db/dbformat.h"
#include "db/filename.h"
#include "db/range_del_view.h"
#include "leveldb/merge_operator.h"
#include "leveldb/env.h"
#include "leveldb/iterator.h"
#include "port/port.h"
#include "util/logging.h"
#include "util/mutexlock.h"
#include "util/random.h"

namespace leveldb {

#if 0
static void DumpInternalIter(Iterator* iter) {
  for (iter->SeekToFirst(); iter->Valid(); iter->Next()) {
    ParsedInternalKey k;
    if (!ParseInternalKey(iter->key(), &k)) {
      std::fprintf(stderr, "Corrupt '%s'\n", EscapeString(iter->key()).c_str());
    } else {
      std::fprintf(stderr, "@ '%s'\n", k.DebugString().c_str());
    }
  }
}
#endif

namespace {

// Memtables and sstables that make the DB representation contain
// (userkey,seq,type) => uservalue entries.  DBIter
// combines multiple entries for the same userkey found in the DB
// representation into a single entry while accounting for sequence
// numbers, deletion markers, overwrites, etc.
class DBIter : public Iterator {
 public:
  // Which direction is the iterator currently moving?
  // (1) When moving forward, the internal iterator is positioned at
  //     the exact entry that yields this->key(), this->value()
  //     Except when that entry is a merge operand: then the operands
  //     have been folded into saved_value_ (merged_ is set, the key is in
  //     merged_key_) and the internal iterator is past all entries of the
  //     key.
  // (2) When moving backwards, the internal iterator is positioned
  //     just before all entries whose user key == this->key().
  enum Direction { kForward, kReverse };

  DBIter(DBImpl* db, const Comparator* cmp, Iterator* iter, SequenceNumber s,
         uint32_t seed, const MergeOperator* merge_op,
         std::shared_ptr<const RangeDelView> range_dels)
      : db_(db),
        user_comparator_(cmp),
        iter_(iter),
        sequence_(s),
        merge_op_(merge_op),
        range_dels_(std::move(range_dels)),
        direction_(kForward),
        valid_(false),
        merged_(false),
        rnd_(seed),
        bytes_until_read_sampling_(RandomCompactionPeriod()) {}

  DBIter(const DBIter&) = delete;
  DBIter& operator=(const DBIter&) = delete;

  ~DBIter() override { delete iter_; }
  bool Valid() const override { return valid_; }
  Slice key() const override {
    assert(valid_);
    if (direction_ == kForward) {
      return merged_ ? Slice(merged_key_) : ExtractUserKey(iter_->key());
    }
    return saved_key_;
  }
  Slice value() const override {
    assert(valid_);
    if (direction_ == kForward && !merged_) return iter_->value();
    return saved_value_;
  }
  Status status() const override {
    if (status_.ok()) {
      return iter_->status();
    } else {
      return status_;
    }
  }

  void Next() override;
  void Prev() override;
  void Seek(const Slice& target) override;
  void SeekToFirst() override;
  void SeekToLast() override;

 private:
  void FindNextUserEntry(bool skipping, std::string* skip);
  void FindPrevUserEntry();
  bool ParseKey(ParsedInternalKey* key);
  void MergeForward(const Slice& user_key);
  bool FullMerge(const std::string* base,
                 const std::vector<std::string>& operands_oldest_first);

  // The entry's type as this iterator sees it: covered by a range
  // tombstone it is a deletion.
  ValueType EffectiveType(const ParsedInternalKey& ikey) const {
    if (ikey.type != kTypeDeletion && range_dels_ != nullptr &&
        range_dels_->Covers(ikey.user_key, ikey.sequence, sequence_)) {
      return kTypeDeletion;
    }
    return ikey.type;
  }

  inline void SaveKey(const Slice& k, std::string* dst) {
    dst->assign(k.data(), k.size());
  }

  inline void ClearSavedValue() {
    if (saved_value_.capacity() > 1048576) {
      std::string empty;
      swap(empty, saved_value_);
    } else {
      saved_value_.clear();
    }
  }

  // Picks the number of bytes that can be read until a compaction is scheduled.
  size_t RandomCompactionPeriod() {
    return rnd_.Uniform(2 * config::kReadBytesPeriod);
  }

  DBImpl* db_;
  const Comparator* const user_comparator_;
  Iterator* const iter_;
  SequenceNumber const sequence_;
  const MergeOperator* const merge_op_;
  const std::shared_ptr<const RangeDelView> range_dels_;
  Status status_;
  std::string saved_key_;    // == current key when direction_==kReverse
  std::string saved_value_;  // == current value when direction_==kReverse
                             //    or merged_
  std::string merged_key_;   // == current key when merged_
  Direction direction_;
  bool valid_;
  bool merged_;
  Random rnd_;
  size_t bytes_until_read_sampling_;
};

inline bool DBIter::ParseKey(ParsedInternalKey* ikey) {
  Slice k = iter_->key();

  size_t bytes_read = k.size() + iter_->value().size();
  while (bytes_until_read_sampling_ < bytes_read) {
    bytes_until_read_sampling_ += RandomCompactionPeriod();
    db_->RecordReadSample(k);
  }
  assert(bytes_until_read_sampling_ >= bytes_read);
  bytes_until_read_sampling_ -= bytes_read;

  if (!ParseInternalKey(k, ikey)) {
    status_ = Status::Corruption("corrupted internal key in DBIter");
    return false;
  } else {
    return true;
  }
}

void DBIter::Next() {
  assert(valid_);

  if (direction_ == kReverse) {  // Switch directions?
    direction_ = kForward;
    // iter_ is pointing just before the entries for this->key(),
    // so advance into the range of entries for this->key() and then
    // use the normal skipping code below.
    if (!iter_->Valid()) {
      iter_->SeekToFirst();
    } else {
      iter_->Next();
    }
    if (!iter_->Valid()) {
      valid_ = false;
      saved_key_.clear();
      return;
    }
    // saved_key_ already contains the key to skip past.
  } else if (merged_) {
    // iter_ is already past the entries of the current key.
    merged_ = false;
    SaveKey(merged_key_, &saved_key_);
    ClearSavedValue();
    if (!iter_->Valid()) {
      valid_ = false;
      saved_key_.clear();
      return;
    }
  } else {
    // Store in saved_key_ the current key so we skip it below.
    SaveKey(ExtractUserKey(iter_->key()), &saved_key_);

    // iter_ is pointing to current key. We can now safely move to the next to
    // avoid checking current key.
    iter_->Next();
    if (!iter_->Valid()) {
      valid_ = false;
      saved_key_.clear();
      return;
    }
  }

  FindNextUserEntry(true, &saved_key_);
}

void DBIter::FindNextUserEntry(bool skipping, std::string* skip) {
  // Loop until we hit an acceptable entry to yield
  assert(iter_->Valid());
  assert(direction_ == kForward);
  do {
    ParsedInternalKey ikey;
    if (ParseKey(&ikey) && ikey.sequence <= sequence_) {
      switch (EffectiveType(ikey)) {
        case kTypeDeletion:
          // Arrange to skip all upcoming entries for this key since
          // they are hidden by this deletion.
          SaveKey(ikey.user_key, skip);
          skipping = true;
          break;
        case kTypeValue:
        case kTypeMerge:
          if (skipping &&
              user_comparator_->Compare(ikey.user_key, *skip) <= 0) {
            // Entry hidden
          } else if (ikey.type == kTypeMerge) {
            saved_key_.clear();
            MergeForward(ikey.user_key);
            return;
          } else {
            valid_ = true;
            saved_key_.clear();
            return;
          }
          break;
        default:
          break;
      }
    }
    iter_->Next();
  } while (iter_->Valid());
  saved_key_.clear();
  valid_ = false;
}

void DBIter::MergeForward(const Slice& user_key) {
  // iter_ is at the newest visible entry of the key, a merge operand.
  merged_key_.assign(user_key.data(), user_key.size());
  std::vector<std::string> operands;  // newest first
  operands.push_back(iter_->value().ToString());
  std::string base;
  bool has_base = false;
  bool settled = false;
  iter_->Next();
  while (iter_->Valid()) {
    ParsedInternalKey ikey;
    if (!ParseKey(&ikey)) break;
    if (user_comparator_->Compare(ikey.user_key, merged_key_) != 0) break;
    if (!settled) {
      switch (EffectiveType(ikey)) {
        case kTypeMerge:
          operands.push_back(iter_->value().ToString());
          break;
        case kTypeValue:
          base = iter_->value().ToString();
          has_base = true;
          settled = true;
          break;
        default:
          settled = true;
          break;
      }
    }
    iter_->Next();
  }
  std::vector<std::string> oldest_first(operands.rbegin(), operands.rend());
  merged_ = true;
  valid_ = FullMerge(has_base ? &base : nullptr, oldest_first);
}

bool DBIter::FullMerge(const std::string* base,
                       const std::vector<std::string>& operands) {
  const Slice key = direction_ == kForward ? Slice(merged_key_) : saved_key_;
  if (merge_op_ == nullptr) {
    status_ = Status::InvalidArgument("merge operand but no merge_operator");
    return false;
  }
  Slice base_slice;
  if (base != nullptr) base_slice = *base;
  std::string result;
  if (!merge_op_->FullMerge(key, base != nullptr ? &base_slice : nullptr,
                            operands, &result)) {
    status_ = Status::Corruption("merge operator failed");
    return false;
  }
  saved_value_.swap(result);
  return true;
}

void DBIter::Prev() {
  assert(valid_);

  if (direction_ == kForward) {  // Switch directions?
    // iter_ is pointing at the current entry (or, after a merge, past the
    // entries of the current key).  Scan backwards until the key changes so
    // we can use the normal reverse scanning code.
    if (merged_) {
      merged_ = false;
      SaveKey(merged_key_, &saved_key_);
      if (!iter_->Valid()) iter_->SeekToLast();
    } else {
      assert(iter_->Valid());  // Otherwise valid_ would have been false
      SaveKey(ExtractUserKey(iter_->key()), &saved_key_);
    }
    while (iter_->Valid() &&
           user_comparator_->Compare(ExtractUserKey(iter_->key()),
                                     saved_key_) >= 0) {
      iter_->Prev();
    }
    if (!iter_->Valid()) {
      valid_ = false;
      saved_key_.clear();
      ClearSavedValue();
      return;
    }
    direction_ = kReverse;
  }

  FindPrevUserEntry();
}

void DBIter::FindPrevUserEntry() {
  assert(direction_ == kReverse);

  // Entries of a key come oldest first here.  value_type is what the
  // newest entry seen so far for saved_key_ makes of it: a deletion (no
  // value), a value (saved_value_), or merge operands on top of whatever
  // was there (has_base says whether that was saved_value_).
  ValueType value_type = kTypeDeletion;
  bool has_base = false;
  std::vector<std::string> operands;  // oldest first
  merged_ = false;
  if (iter_->Valid()) {
    do {
      ParsedInternalKey ikey;
      if (ParseKey(&ikey) && ikey.sequence <= sequence_) {
        if ((value_type != kTypeDeletion) &&
            user_comparator_->Compare(ikey.user_key, saved_key_) < 0) {
          // We encountered a non-deleted value in entries for previous keys,
          break;
        }
        switch (EffectiveType(ikey)) {
          case kTypeDeletion:
            value_type = kTypeDeletion;
            saved_key_.clear();
            ClearSavedValue();
            operands.clear();
            has_base = false;
            break;
          case kTypeValue: {
            value_type = kTypeValue;
            Slice raw_value = iter_->value();
            if (saved_value_.capacity() > raw_value.size() + 1048576) {
              std::string empty;
              swap(empty, saved_value_);
            }
            SaveKey(ExtractUserKey(iter_->key()), &saved_key_);
            saved_value_.assign(raw_value.data(), raw_value.size());
            operands.clear();
            has_base = true;
            break;
          }
          case kTypeMerge:
            if (value_type == kTypeDeletion) {
              SaveKey(ExtractUserKey(iter_->key()), &saved_key_);
              ClearSavedValue();
              has_base = false;
              operands.clear();
            }
            value_type = kTypeMerge;
            operands.push_back(iter_->value().ToString());
            break;
          default:
            break;
        }
      }
      iter_->Prev();
    } while (iter_->Valid());
  }

  if (value_type == kTypeDeletion) {
    // End
    valid_ = false;
    saved_key_.clear();
    ClearSavedValue();
    direction_ = kForward;
  } else if (!operands.empty()) {
    std::string base;
    if (has_base) base.swap(saved_value_);
    valid_ = FullMerge(has_base ? &base : nullptr, operands);
  } else {
    valid_ = true;
  }
}

void DBIter::Seek(const Slice& target) {
  direction_ = kForward;
  merged_ = false;
  ClearSavedValue();
  saved_key_.clear();
  AppendInternalKey(&saved_key_,
                    ParsedInternalKey(target, sequence_, kValueTypeForSeek));
  iter_->Seek(saved_key_);
  if (iter_->Valid()) {
    FindNextUserEntry(false, &saved_key_ /* temporary storage */);
  } else {
    valid_ = false;
  }
}

void DBIter::SeekToFirst() {
  direction_ = kForward;
  merged_ = false;
  ClearSavedValue();
  iter_->SeekToFirst();
  if (iter_->Valid()) {
    FindNextUserEntry(false, &saved_key_ /* temporary storage */);
  } else {
    valid_ = false;
  }
}

void DBIter::SeekToLast() {
  direction_ = kReverse;
  merged_ = false;
  ClearSavedValue();
  iter_->SeekToLast();
  FindPrevUserEntry();
}

}  // anonymous namespace

Iterator* NewDBIterator(DBImpl* db, const Comparator* user_key_comparator,
                        Iterator* internal_iter, SequenceNumber sequence,
                        uint32_t seed, const MergeOperator* merge_op,
                        std::shared_ptr<const RangeDelView> range_dels) {
  return new DBIter(db, user_key_comparator, internal_iter, sequence, seed,
                    merge_op, std::move(range_dels));
}

}  // namespace leveldb
