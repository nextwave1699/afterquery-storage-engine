// Copyright (c) 2011 The LevelDB Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file. See the AUTHORS file for names of contributors.

#include "db/column_family.h"

#include <cstdlib>

#include "db/filename.h"
#include "leveldb/env.h"
#include "util/logging.h"

namespace leveldb {

const char* kDefaultColumnFamilyName = "default";

ColumnFamilyHandle::~ColumnFamilyHandle() = default;

ColumnFamilyDescriptor::ColumnFamilyDescriptor()
    : name(kDefaultColumnFamilyName) {}

std::string FamiliesFileName(const std::string& dbname) {
  return dbname + "/FAMILIES";
}

Status ReadFamilies(Env* env, const std::string& dbname,
                    std::vector<std::pair<uint32_t, std::string>>* families,
                    uint32_t* next_id) {
  families->clear();
  *next_id = 1;
  std::string contents;
  Status s = ReadFileToString(env, FamiliesFileName(dbname), &contents);
  if (!s.ok()) {
    // No file: the database has the default family only.
    return s.IsNotFound() ? Status::OK() : s;
  }
  size_t pos = 0;
  bool first = true;
  while (pos < contents.size()) {
    size_t end = contents.find('\n', pos);
    if (end == std::string::npos) end = contents.size();
    std::string line = contents.substr(pos, end - pos);
    pos = end + 1;
    if (line.empty()) continue;
    if (first) {
      *next_id = static_cast<uint32_t>(strtoul(line.c_str(), nullptr, 10));
      first = false;
      continue;
    }
    size_t space = line.find(' ');
    if (space == std::string::npos) {
      return Status::Corruption("malformed FAMILIES line", line);
    }
    uint32_t id = static_cast<uint32_t>(strtoul(line.c_str(), nullptr, 10));
    if (id == 0) return Status::Corruption("bad family id in FAMILIES", line);
    families->emplace_back(id, line.substr(space + 1));
  }
  if (first) return Status::Corruption("empty FAMILIES file");
  return Status::OK();
}

Status WriteFamilies(Env* env, const std::string& dbname,
                     const std::vector<std::pair<uint32_t, std::string>>& families,
                     uint32_t next_id) {
  std::string contents = std::to_string(next_id) + "\n";
  for (const auto& f : families) {
    contents += std::to_string(f.first) + " " + f.second + "\n";
  }
  const std::string path = FamiliesFileName(dbname);
  const std::string tmp = path + ".dbtmp";
  WritableFile* file;
  Status s = env->NewWritableFile(tmp, &file);
  if (!s.ok()) return s;
  s = file->Append(contents);
  if (s.ok()) s = file->Sync();
  if (s.ok()) s = file->Close();
  delete file;
  if (s.ok()) {
    s = env->RenameFile(tmp, path);
  } else {
    env->RemoveFile(tmp);
  }
  return s;
}

}  // namespace leveldb
