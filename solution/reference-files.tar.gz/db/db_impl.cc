// Copyright (c) 2011 The LevelDB Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file. See the AUTHORS file for names of contributors.

#include "db/db_impl.h"

#include <algorithm>
#include <atomic>
#include <cstdint>
#include <cstdio>
#include <set>
#include <string>
#include <vector>

#include "db/builder.h"
#include "db/column_family.h"
#include "db/lookup_state.h"
#include "db/range_del.h"
#include "db/db_iter.h"
#include "db/dbformat.h"
#include "db/filename.h"
#include "db/log_reader.h"
#include "db/log_writer.h"
#include "db/memtable.h"
#include "db/table_cache.h"
#include "db/version_set.h"
#include "db/write_batch_internal.h"
#include "leveldb/db.h"
#include "leveldb/env.h"
#include "leveldb/merge_operator.h"
#include "leveldb/status.h"
#include "leveldb/table.h"
#include "leveldb/table_builder.h"
#include "port/port.h"
#include "table/block.h"
#include "table/merger.h"
#include "table/two_level_iterator.h"
#include "util/coding.h"
#include "util/logging.h"
#include "util/mutexlock.h"

namespace leveldb {

const int kNumNonTableCacheFiles = 10;

// Information kept for every waiting writer
struct DBImpl::Writer {
  explicit Writer(port::Mutex* mu)
      : batch(nullptr), sync(false), done(false), cv(mu) {}

  Status status;
  WriteBatch* batch;
  bool sync;
  bool done;
  port::CondVar cv;
};

struct DBImpl::CompactionState {
  // Files produced by compaction
  struct Output {
    uint64_t number;
    uint64_t file_size;
    InternalKey smallest, largest;
    bool has_range_dels = false;
  };

  Output* current_output() { return &outputs[outputs.size() - 1]; }

  explicit CompactionState(Compaction* c)
      : compaction(c),
        smallest_snapshot(0),
        outfile(nullptr),
        builder(nullptr),
        total_bytes(0) {}

  Compaction* const compaction;
  ColumnFamily* cf = nullptr;

  // Sequence numbers < smallest_snapshot are not significant since we
  // will never have to service a snapshot below smallest_snapshot.
  // Therefore if we have seen a sequence number S <= smallest_snapshot,
  // we can drop all entries for the same key with sequence numbers < S.
  SequenceNumber smallest_snapshot;

  std::vector<Output> outputs;

  // State kept for output being generated
  WritableFile* outfile;
  TableBuilder* builder;

  uint64_t total_bytes;

  // Range tombstones to carry into the outputs, sorted by begin key.  Each
  // output file gets the part of them between its cut points.
  std::vector<RangeTombstone> tombstones;
  // Where the current output file starts (the previous file's cut); empty
  // with has_lower_cut false for the first file.
  std::string lower_cut;
  bool has_lower_cut = false;
};

// Fix user-supplied options to be reasonable
template <class T, class V>
static void ClipToRange(T* ptr, V minvalue, V maxvalue) {
  if (static_cast<V>(*ptr) > maxvalue) *ptr = maxvalue;
  if (static_cast<V>(*ptr) < minvalue) *ptr = minvalue;
}
Options SanitizeOptions(const std::string& dbname,
                        const InternalKeyComparator* icmp,
                        const InternalFilterPolicy* ipolicy,
                        const Options& src) {
  Options result = src;
  result.comparator = icmp;
  result.filter_policy = (src.filter_policy != nullptr) ? ipolicy : nullptr;
  ClipToRange(&result.max_open_files, 64 + kNumNonTableCacheFiles, 50000);
  ClipToRange(&result.write_buffer_size, 64 << 10, 1 << 30);
  ClipToRange(&result.max_file_size, 1 << 20, 1 << 30);
  ClipToRange(&result.block_size, 1 << 10, 4 << 20);
  if (result.info_log == nullptr) {
    // Open a log file in the same directory as the db
    src.env->CreateDir(dbname);  // In case it does not exist
    src.env->RenameFile(InfoLogFileName(dbname), OldInfoLogFileName(dbname));
    Status s = src.env->NewLogger(InfoLogFileName(dbname), &result.info_log);
    if (!s.ok()) {
      // No place suitable for logging
      result.info_log = nullptr;
    }
  }
  if (result.block_cache == nullptr) {
    result.block_cache = NewLRUCache(8 << 20);
  }
  return result;
}

// How many log files may pile up before the families that hold the oldest
// one back are flushed.
static const int kMaxLiveLogs = 3;

static int TableCacheSize(const Options& sanitized_options) {
  // Reserve ten files or so for other uses and give the rest to TableCache.
  return sanitized_options.max_open_files - kNumNonTableCacheFiles;
}

DBImpl::DBImpl(const Options& raw_options, const std::string& dbname)
    : env_(raw_options.env),
      user_comparator_(raw_options.comparator),
      db_options_(SanitizeOptions(dbname, nullptr, nullptr, raw_options)),
      owns_info_log_(db_options_.info_log != raw_options.info_log),
      owns_cache_(db_options_.block_cache != raw_options.block_cache),
      dbname_(dbname),
      db_lock_(nullptr),
      shutting_down_(false),
      background_work_finished_signal_(&mutex_),
      logfile_(nullptr),
      logfile_number_(0),
      log_(nullptr),
      seed_(0),
      tmp_batch_(new WriteBatch),
      background_compaction_scheduled_(false) {}

DBImpl::~DBImpl() {
  // Wait for background work to finish.
  mutex_.Lock();
  shutting_down_.store(true, std::memory_order_release);
  while (background_compaction_scheduled_) {
    background_work_finished_signal_.Wait();
  }
  mutex_.Unlock();

  if (db_lock_ != nullptr) {
    env_->UnlockFile(db_lock_);
  }

  for (auto& entry : cfs_) {
    ColumnFamily* cf = entry.second;
    delete cf->versions;
    if (cf->mem != nullptr) cf->mem->Unref();
    if (cf->imm != nullptr) cf->imm->Unref();
    delete cf->table_cache;
    delete cf;
  }
  cfs_.clear();
  delete default_handle_;
  delete tmp_batch_;
  delete log_;
  delete logfile_;

  if (owns_info_log_) {
    delete db_options_.info_log;
  }
  if (owns_cache_) {
    delete db_options_.block_cache;
  }
}

ColumnFamily* DBImpl::FamilyOf(ColumnFamilyHandle* handle) const {
  if (handle == nullptr) return default_cf_;
  return static_cast<ColumnFamilyHandleImpl*>(handle)->cf();
}

Status DBImpl::CheckFamily(ColumnFamilyHandle* handle,
                           ColumnFamily** cf) const {
  if (handle != nullptr) {
    ColumnFamilyHandleImpl* impl = static_cast<ColumnFamilyHandleImpl*>(handle);
    if (impl->db() != this) {
      return Status::InvalidArgument("column family of another database");
    }
  }
  ColumnFamily* found = FamilyOf(handle);
  if (found == nullptr) return Status::InvalidArgument("no such column family");
  if (found->dropped) {
    return Status::InvalidArgument("column family dropped", found->name);
  }
  *cf = found;
  return Status::OK();
}

Status DBImpl::NewDB(const std::string& dir) {
  VersionEdit new_db;
  new_db.SetComparatorName(user_comparator()->Name());
  new_db.SetLogNumber(0);
  new_db.SetNextFile(2);
  new_db.SetLastSequence(0);

  const std::string manifest = DescriptorFileName(dir, 1);
  WritableFile* file;
  Status s = env_->NewWritableFile(manifest, &file);
  if (!s.ok()) {
    return s;
  }
  {
    log::Writer log(file);
    std::string record;
    new_db.EncodeTo(&record);
    s = log.AddRecord(record);
    if (s.ok()) {
      s = file->Sync();
    }
    if (s.ok()) {
      s = file->Close();
    }
  }
  delete file;
  if (s.ok()) {
    // Make "CURRENT" file that points to the new manifest file.
    s = SetCurrentFile(env_, dir, 1);
  } else {
    env_->RemoveFile(manifest);
  }
  return s;
}

void DBImpl::MaybeIgnoreError(Status* s) const {
  if (s->ok() || db_options_.paranoid_checks) {
    // No change needed
  } else {
    Log(db_options_.info_log, "Ignoring error %s", s->ToString().c_str());
    *s = Status::OK();
  }
}

uint64_t DBImpl::OldestLiveLog() const {
  uint64_t oldest = logfile_number_;
  for (const auto& entry : cfs_) {
    ColumnFamily* cf = entry.second;
    if (cf->dropped) continue;
    // Everything before the family's log number is in its tables; what its
    // memtables hold starts at the log they were opened on.
    uint64_t needed = cf->versions->LogNumber();
    if (cf->imm != nullptr) {
      needed = std::min(needed, cf->imm_log_number);
    } else if (cf->mem != nullptr) {
      needed = std::min(needed, cf->mem_log_number);
    }
    oldest = std::min(oldest, needed);
  }
  return oldest;
}

void DBImpl::RemoveObsoleteFiles() {
  mutex_.AssertHeld();

  if (!bg_error_.ok()) {
    // After a background error, we don't know whether a new version may
    // or may not have been committed, so we cannot safely garbage collect.
    return;
  }

  const uint64_t oldest_log = OldestLiveLog();
  std::vector<std::string> files_to_delete;  // full paths

  for (const auto& entry : cfs_) {
    ColumnFamily* cf = entry.second;
    // Make a set of all of the live files of this family
    std::set<uint64_t> live = cf->pending_outputs;
    cf->versions->AddLiveFiles(&live);

    std::vector<std::string> filenames;
    env_->GetChildren(cf->dir, &filenames);  // Ignoring errors on purpose
    uint64_t number;
    FileType type;
    for (std::string& filename : filenames) {
      if (!ParseFileName(filename, &number, &type)) continue;
      bool keep = true;
      switch (type) {
        case kLogFile:
          // The logs are the database's, not the family's; only the
          // default family's directory holds them.
          keep = (cf->id != 0) || (number >= oldest_log);
          break;
        case kDescriptorFile:
          // Keep my manifest file, and any newer incarnations'
          // (in case there is a race that allows other incarnations)
          keep = (number >= cf->versions->ManifestFileNumber());
          break;
        case kTableFile:
        case kTempFile:
          // Any temp files that are currently being written to must
          // be recorded in pending_outputs, which is inserted into "live"
          keep = (live.find(number) != live.end());
          break;
        case kCurrentFile:
        case kDBLockFile:
        case kInfoLogFile:
          keep = true;
          break;
      }

      if (!keep) {
        files_to_delete.push_back(cf->dir + "/" + filename);
        if (type == kTableFile) {
          cf->table_cache->Evict(number);
        }
        Log(db_options_.info_log, "Delete type=%d #%lld\n",
            static_cast<int>(type), static_cast<unsigned long long>(number));
      }
    }
  }

  // While deleting all files unblock other threads. All files being deleted
  // have unique names which will not collide with newly created files and
  // are therefore safe to delete while allowing other threads to proceed.
  mutex_.Unlock();
  for (const std::string& filename : files_to_delete) {
    env_->RemoveFile(filename);
  }
  mutex_.Lock();
}

Status DBImpl::OpenColumnFamily(ColumnFamily* cf, bool* save_manifest,
                                VersionEdit* edit) {
  mutex_.AssertHeld();
  cf->table_cache =
      new TableCache(cf->dir, cf->options, TableCacheSize(cf->options));
  cf->versions =
      new VersionSet(cf->dir, &cf->options, cf->table_cache, &cf->icmp);
  Status s = cf->versions->Recover(save_manifest);
  if (!s.ok()) return s;
  std::set<uint64_t> expected;
  cf->versions->AddLiveFiles(&expected);
  std::vector<std::string> filenames;
  s = env_->GetChildren(cf->dir, &filenames);
  if (!s.ok()) return s;
  uint64_t number;
  FileType type;
  for (size_t i = 0; i < filenames.size(); i++) {
    if (ParseFileName(filenames[i], &number, &type)) expected.erase(number);
  }
  if (!expected.empty()) {
    char buf[64];
    std::snprintf(buf, sizeof(buf), "%d missing files of family %s; e.g.",
                  static_cast<int>(expected.size()), cf->name.c_str());
    return Status::Corruption(buf, TableFileName(cf->dir, *(expected.begin())));
  }
  return Status::OK();
}

Status DBImpl::Recover(const std::vector<ColumnFamilyDescriptor>& families,
                       bool create_missing_families, bool* save_manifest) {
  mutex_.AssertHeld();

  // Ignore error from CreateDir since the creation of the DB is
  // committed only when the descriptor is created, and this directory
  // may already exist from a previous failed creation attempt.
  env_->CreateDir(dbname_);
  assert(db_lock_ == nullptr);
  Status s = env_->LockFile(LockFileName(dbname_), &db_lock_);
  if (!s.ok()) {
    return s;
  }

  const bool existed = env_->FileExists(CurrentFileName(dbname_));
  if (!existed) {
    if (db_options_.create_if_missing) {
      Log(db_options_.info_log, "Creating DB %s since it was missing.",
          dbname_.c_str());
      s = NewDB(dbname_);
      if (!s.ok()) {
        return s;
      }
    } else {
      return Status::InvalidArgument(
          dbname_, "does not exist (create_if_missing is false)");
    }
  } else {
    if (db_options_.error_if_exists) {
      return Status::InvalidArgument(dbname_,
                                     "exists (error_if_exists is true)");
    }
  }

  // Which families does the database have?
  std::vector<std::pair<uint32_t, std::string>> on_disk;
  s = ReadFamilies(env_, dbname_, &on_disk, &next_family_id_);
  if (!s.ok()) return s;

  // What the caller asked for, by name.
  std::map<std::string, const ColumnFamilyDescriptor*> wanted;
  for (const ColumnFamilyDescriptor& d : families) {
    if (!wanted.emplace(d.name, &d).second) {
      return Status::InvalidArgument("duplicate column family", d.name);
    }
  }
  const bool by_name = !families.empty();
  if (!by_name && !on_disk.empty()) {
    return Status::InvalidArgument(
        dbname_, "has column families; open it with their descriptors");
  }
  if (by_name && wanted.find(kDefaultColumnFamilyName) == wanted.end()) {
    return Status::InvalidArgument("the default column family must be opened");
  }

  auto options_for = [&](const std::string& name) {
    auto it = wanted.find(name);
    return it == wanted.end() ? db_options_ : it->second->options;
  };

  // Open the default family, then the others the database has.
  std::vector<std::pair<uint32_t, std::string>> all;
  all.emplace_back(0, std::string(kDefaultColumnFamilyName));
  for (const auto& f : on_disk) all.push_back(f);
  for (const auto& f : all) {
    if (by_name && wanted.find(f.second) == wanted.end()) {
      return Status::InvalidArgument("column family not opened", f.second);
    }
  }
  for (const auto& f : all) {
    Options raw = options_for(f.second);
    raw.env = env_;
    raw.info_log = db_options_.info_log;
    raw.block_cache = db_options_.block_cache;
    raw.max_open_files = db_options_.max_open_files;
    raw.comparator = user_comparator_;
    ColumnFamily* cf = new ColumnFamily(f.first, f.second,
                                        ColumnFamilyDir(dbname_, f.first), raw,
                                        user_comparator_);
    cf->options = SanitizeOptions(cf->dir, &cf->icmp, &cf->ipolicy, raw);
    cf->options.info_log = db_options_.info_log;
    cf->options.block_cache = db_options_.block_cache;
    cf->refs = 1;
    cfs_[cf->id] = cf;
    if (cf->id == 0) default_cf_ = cf;
    VersionEdit edit;
    bool cf_save = false;
    s = OpenColumnFamily(cf, &cf_save, &edit);
    if (!s.ok()) return s;
    if (cf_save) *save_manifest = true;
  }

  // Create the ones that are missing, if allowed.
  if (by_name) {
    for (const ColumnFamilyDescriptor& d : families) {
      bool have = false;
      for (const auto& f : all) have = have || (f.second == d.name);
      if (have) continue;
      if (!create_missing_families) {
        return Status::InvalidArgument("column family does not exist", d.name);
      }
      ColumnFamilyHandle* handle = nullptr;
      s = CreateColumnFamilyLocked(d.options, d.name, &handle);
      if (!s.ok()) return s;
      delete handle;  // handles are handed out by Open
    }
  }

  SequenceNumber max_sequence(0);
  for (const auto& entry : cfs_) {
    max_sequence = std::max(max_sequence, entry.second->versions->LastSequence());
  }

  // Recover from all newer log files than the ones named in the
  // descriptors (new log files may have been added by the previous
  // incarnation without registering them in a descriptor).
  uint64_t min_log = default_cf_->versions->LogNumber();
  const uint64_t prev_log = default_cf_->versions->PrevLogNumber();
  for (const auto& entry : cfs_) {
    min_log = std::min(min_log, entry.second->versions->LogNumber());
  }
  std::vector<std::string> filenames;
  s = env_->GetChildren(dbname_, &filenames);
  if (!s.ok()) {
    return s;
  }
  uint64_t number;
  FileType type;
  std::vector<uint64_t> logs;
  for (size_t i = 0; i < filenames.size(); i++) {
    if (ParseFileName(filenames[i], &number, &type)) {
      if (type == kLogFile && ((number >= min_log) || (number == prev_log)))
        logs.push_back(number);
    }
  }

  // Recover in the order in which the logs were generated
  std::sort(logs.begin(), logs.end());
  for (size_t i = 0; i < logs.size(); i++) {
    s = RecoverLogFile(logs[i], (i == logs.size() - 1), &max_sequence);
    if (!s.ok()) {
      return s;
    }
    *save_manifest = true;

    // The previous incarnation may not have written any MANIFEST
    // records after allocating this log number.  So we manually
    // update the file number allocation counter in every family's
    // VersionSet: they share the database's log numbers.
    for (const auto& entry : cfs_) {
      entry.second->versions->MarkFileNumberUsed(logs[i]);
    }
  }

  last_sequence_ = max_sequence;
  for (const auto& entry : cfs_) {
    if (entry.second->versions->LastSequence() < max_sequence) {
      entry.second->versions->SetLastSequence(max_sequence);
    }
  }

  return Status::OK();
}

Status DBImpl::RecoverLogFile(uint64_t log_number, bool last_log,
                              SequenceNumber* max_sequence) {
  struct LogReporter : public log::Reader::Reporter {
    Env* env;
    Logger* info_log;
    const char* fname;
    Status* status;  // null if db_options_.paranoid_checks==false
    void Corruption(size_t bytes, const Status& s) override {
      Log(info_log, "%s%s: dropping %d bytes; %s",
          (this->status == nullptr ? "(ignoring error) " : ""), fname,
          static_cast<int>(bytes), s.ToString().c_str());
      if (this->status != nullptr && this->status->ok()) *this->status = s;
    }
  };

  mutex_.AssertHeld();

  // Open the log file
  std::string fname = LogFileName(dbname_, log_number);
  SequentialFile* file;
  Status status = env_->NewSequentialFile(fname, &file);
  if (!status.ok()) {
    MaybeIgnoreError(&status);
    return status;
  }

  // Create the log reader.
  LogReporter reporter;
  reporter.env = env_;
  reporter.info_log = db_options_.info_log;
  reporter.fname = fname.c_str();
  reporter.status = (db_options_.paranoid_checks ? &status : nullptr);
  // We intentionally make log::Reader do checksumming even if
  // paranoid_checks==false so that corruptions cause entire commits
  // to be skipped instead of propagating bad information (like overly
  // large sequence numbers).
  log::Reader reader(file, &reporter, true /*checksum*/, 0 /*initial_offset*/);
  Log(db_options_.info_log, "Recovering log #%llu",
      (unsigned long long)log_number);

  // Every family whose data of this log is not in its tables yet gets a
  // memtable; the others skip the records of this log.
  std::map<uint32_t, MemTable*> mems;
  std::map<uint32_t, ColumnFamily*> replaying;
  for (const auto& entry : cfs_) {
    ColumnFamily* cf = entry.second;
    if (cf->dropped || cf->versions->LogNumber() > log_number) continue;
    replaying[cf->id] = cf;
  }

  // Read all the records and add them to the memtables
  std::string scratch;
  Slice record;
  WriteBatch batch;
  int compactions = 0;
  while (reader.ReadRecord(&record, &scratch) && status.ok()) {
    if (record.size() < 12) {
      reporter.Corruption(record.size(),
                          Status::Corruption("log record too small"));
      continue;
    }
    WriteBatchInternal::SetContents(&batch, record);

    for (const auto& entry : replaying) {
      if (mems.find(entry.first) == mems.end()) {
        MemTable* mem = new MemTable(entry.second->icmp);
        mem->Ref();
        mems[entry.first] = mem;
      }
    }
    status = WriteBatchInternal::InsertInto(&batch, mems);
    MaybeIgnoreError(&status);
    if (!status.ok()) {
      break;
    }
    const SequenceNumber last_seq = WriteBatchInternal::Sequence(&batch) +
                                    WriteBatchInternal::Count(&batch) - 1;
    if (last_seq > *max_sequence) {
      *max_sequence = last_seq;
    }

    for (auto it = mems.begin(); it != mems.end();) {
      ColumnFamily* cf = replaying[it->first];
      if (it->second->ApproximateMemoryUsage() > cf->options.write_buffer_size) {
        compactions++;
        status = WriteLevel0Table(cf, it->second, &recovery_edits_[cf->id],
                                  nullptr);
        it->second->Unref();
        it = mems.erase(it);
        if (!status.ok()) break;
      } else {
        ++it;
      }
    }
    if (!status.ok()) break;
  }

  delete file;

  // See if we should keep reusing the last log file.  Only with the default
  // family alone: with several families the log is shared and reusing it
  // would tangle their flush points.
  if (status.ok() && db_options_.reuse_logs && last_log && compactions == 0 &&
      cfs_.size() == 1 && default_cf_->mem == nullptr) {
    assert(logfile_ == nullptr);
    assert(log_ == nullptr);
    uint64_t lfile_size;
    if (env_->GetFileSize(fname, &lfile_size).ok() &&
        env_->NewAppendableFile(fname, &logfile_).ok()) {
      Log(db_options_.info_log, "Reusing old log %s \n", fname.c_str());
      log_ = new log::Writer(logfile_, lfile_size);
      logfile_number_ = log_number;
      auto it = mems.find(0);
      if (it != mems.end()) {
        default_cf_->mem = it->second;
        mems.erase(it);
      } else {
        // the log existed but was empty
        default_cf_->mem = new MemTable(default_cf_->icmp);
        default_cf_->mem->Ref();
      }
      default_cf_->mem_log_number = log_number;
      return status;
    }
  }

  for (auto& entry : mems) {
    ColumnFamily* cf = replaying[entry.first];
    if (status.ok()) {
      status = WriteLevel0Table(cf, entry.second, &recovery_edits_[cf->id],
                                nullptr);
    }
    entry.second->Unref();
  }

  return status;
}

Status DBImpl::WriteLevel0Table(ColumnFamily* cf, MemTable* mem,
                                VersionEdit* edit, Version* base) {
  mutex_.AssertHeld();
  const uint64_t start_micros = env_->NowMicros();
  FileMetaData meta;
  meta.number = cf->versions->NewFileNumber();
  cf->pending_outputs.insert(meta.number);
  Iterator* iter = mem->NewIterator();
  Log(db_options_.info_log, "Level-0 table #%llu: started",
      (unsigned long long)meta.number);

  std::vector<RangeTombstone> tombstones;
  mem->GetRangeTombstones(&tombstones);

  Status s;
  {
    mutex_.Unlock();
    s = BuildTable(cf->dir, env_, cf->options, cf->table_cache, iter, &meta,
                   tombstones);
    mutex_.Lock();
  }

  Log(db_options_.info_log, "Level-0 table #%llu: %lld bytes %s",
      (unsigned long long)meta.number, (unsigned long long)meta.file_size,
      s.ToString().c_str());
  delete iter;
  cf->pending_outputs.erase(meta.number);

  // Note that if file_size is zero, the file has been deleted and
  // should not be added to the manifest.
  int level = 0;
  if (s.ok() && meta.file_size > 0) {
    const Slice min_user_key = meta.smallest.user_key();
    const Slice max_user_key = meta.largest.user_key();
    if (base != nullptr) {
      level = base->PickLevelForMemTableOutput(min_user_key, max_user_key);
    }
    edit->AddFile(level, meta.number, meta.file_size, meta.smallest,
                  meta.largest, meta.has_range_dels);
  }

  CompactionStats stats;
  stats.micros = env_->NowMicros() - start_micros;
  stats.bytes_written = meta.file_size;
  cf->stats[level].Add(stats);
  return s;
}

void DBImpl::CompactMemTable(ColumnFamily* cf) {
  mutex_.AssertHeld();
  assert(cf->imm != nullptr);

  // Save the contents of the memtable as a new Table
  VersionEdit edit;
  Version* base = cf->versions->current();
  base->Ref();
  Status s = WriteLevel0Table(cf, cf->imm, &edit, base);
  base->Unref();

  if (s.ok() && shutting_down_.load(std::memory_order_acquire)) {
    s = Status::IOError("Deleting DB during memtable compaction");
  }

  // Replace immutable memtable with the generated Table
  if (s.ok()) {
    edit.SetPrevLogNumber(0);
    // Every log below the one the current memtable writes to is now in
    // this family's tables.
    edit.SetLogNumber(cf->mem_log_number);
    s = cf->versions->LogAndApply(&edit, &mutex_);
  }

  if (s.ok()) {
    // Commit to the new state
    cf->imm->Unref();
    cf->imm = nullptr;
    cf->has_imm.store(false, std::memory_order_release);
    bool any = false;
    for (const auto& entry : cfs_) {
      any = any || (entry.second->imm != nullptr);
    }
    pending_flush_.store(any, std::memory_order_release);
    RemoveObsoleteFiles();
  } else {
    RecordBackgroundError(s);
  }
}

void DBImpl::CompactRange(const Slice* begin, const Slice* end) {
  CompactRange(nullptr, begin, end);
}

void DBImpl::CompactRange(ColumnFamilyHandle* handle, const Slice* begin,
                          const Slice* end) {
  ColumnFamily* cf = nullptr;
  if (!CheckFamily(handle, &cf).ok()) return;
  int max_level_with_files = 1;
  {
    MutexLock l(&mutex_);
    Version* base = cf->versions->current();
    for (int level = 1; level < config::kNumLevels; level++) {
      if (base->OverlapInLevel(level, begin, end)) {
        max_level_with_files = level;
      }
    }
  }
  TEST_CompactMemTable();  // TODO(sanjay): Skip if memtable does not overlap
  for (int level = 0; level < max_level_with_files; level++) {
    TEST_CompactRange(level, begin, end);
  }
}

void DBImpl::TEST_CompactRange(int level, const Slice* begin,
                               const Slice* end) {
  ColumnFamily* cf = default_cf_;
  assert(level >= 0);
  assert(level + 1 < config::kNumLevels);

  InternalKey begin_storage, end_storage;

  ManualCompaction manual;
  manual.level = level;
  manual.done = false;
  if (begin == nullptr) {
    manual.begin = nullptr;
  } else {
    begin_storage = InternalKey(*begin, kMaxSequenceNumber, kValueTypeForSeek);
    manual.begin = &begin_storage;
  }
  if (end == nullptr) {
    manual.end = nullptr;
  } else {
    end_storage = InternalKey(*end, 0, static_cast<ValueType>(0));
    manual.end = &end_storage;
  }

  MutexLock l(&mutex_);
  while (!manual.done && !shutting_down_.load(std::memory_order_acquire) &&
         bg_error_.ok()) {
    if (cf->manual == nullptr) {  // Idle
      cf->manual = &manual;
      MaybeScheduleCompaction();
    } else {  // Running either my compaction or another compaction.
      background_work_finished_signal_.Wait();
    }
  }
  if (cf->manual == &manual) {
    // Cancel my manual compaction since we aborted early for some reason.
    cf->manual = nullptr;
  }
}

Status DBImpl::TEST_CompactMemTable() {
  ColumnFamily* cf = default_cf_;
  // nullptr batch means just wait for earlier writes to be done
  Status s = Write(WriteOptions(), nullptr);
  if (s.ok()) {
    // Wait until the compaction completes
    MutexLock l(&mutex_);
    while (cf->imm != nullptr && bg_error_.ok()) {
      background_work_finished_signal_.Wait();
    }
    if (cf->imm != nullptr) {
      s = bg_error_;
    }
  }
  return s;
}

void DBImpl::RecordBackgroundError(const Status& s) {
  mutex_.AssertHeld();
  if (bg_error_.ok()) {
    bg_error_ = s;
    background_work_finished_signal_.SignalAll();
  }
}

bool DBImpl::NeedsBackgroundWork() const {
  for (const auto& entry : cfs_) {
    ColumnFamily* cf = entry.second;
    if (cf->dropped) continue;
    if (cf->imm != nullptr || cf->manual != nullptr ||
        cf->versions->NeedsCompaction()) {
      return true;
    }
  }
  return false;
}

void DBImpl::MaybeScheduleCompaction() {
  mutex_.AssertHeld();
  if (background_compaction_scheduled_) {
    // Already scheduled
  } else if (shutting_down_.load(std::memory_order_acquire)) {
    // DB is being deleted; no more background compactions
  } else if (!bg_error_.ok()) {
    // Already got an error; no more changes
  } else if (!NeedsBackgroundWork()) {
    // No work to be done
  } else {
    background_compaction_scheduled_ = true;
    env_->Schedule(&DBImpl::BGWork, this);
  }
}

void DBImpl::BGWork(void* db) {
  reinterpret_cast<DBImpl*>(db)->BackgroundCall();
}

void DBImpl::BackgroundCall() {
  MutexLock l(&mutex_);
  assert(background_compaction_scheduled_);
  if (shutting_down_.load(std::memory_order_acquire)) {
    // No more background work when shutting down.
  } else if (!bg_error_.ok()) {
    // No more background work after a background error.
  } else {
    BackgroundCompaction();
  }

  background_compaction_scheduled_ = false;

  // Previous compaction may have produced too many files in a level,
  // so reschedule another compaction if needed.
  MaybeScheduleCompaction();
  background_work_finished_signal_.SignalAll();
}

void DBImpl::BackgroundCompaction() {
  mutex_.AssertHeld();

  // Flushing a memtable comes first, then a manual compaction, then
  // whichever family most needs one.  Families are taken in id order, so
  // no family can starve another for long.
  ColumnFamily* cf = nullptr;
  for (const auto& entry : cfs_) {
    if (!entry.second->dropped && entry.second->imm != nullptr) {
      cf = entry.second;
      break;
    }
  }
  if (cf != nullptr) {
    CompactMemTable(cf);
    return;
  }
  for (const auto& entry : cfs_) {
    if (!entry.second->dropped && entry.second->manual != nullptr) {
      cf = entry.second;
      break;
    }
  }
  if (cf == nullptr) {
    double best = -1;
    for (const auto& entry : cfs_) {
      ColumnFamily* candidate = entry.second;
      if (candidate->dropped || !candidate->versions->NeedsCompaction()) continue;
      const double score = candidate->versions->current()->CompactionScore();
      if (cf == nullptr || score > best) {
        cf = candidate;
        best = score;
      }
    }
  }
  if (cf == nullptr) return;

  Compaction* c;
  bool is_manual = (cf->manual != nullptr);
  InternalKey manual_end;
  if (is_manual) {
    ManualCompaction* m = cf->manual;
    c = cf->versions->CompactRange(m->level, m->begin, m->end);
    m->done = (c == nullptr);
    if (c != nullptr) {
      manual_end = c->input(0, c->num_input_files(0) - 1)->largest;
    }
    Log(db_options_.info_log,
        "Manual compaction of %s at level-%d from %s .. %s; will stop at %s\n",
        cf->name.c_str(), m->level,
        (m->begin ? m->begin->DebugString().c_str() : "(begin)"),
        (m->end ? m->end->DebugString().c_str() : "(end)"),
        (m->done ? "(end)" : manual_end.DebugString().c_str()));
  } else {
    c = cf->versions->PickCompaction();
  }

  Status status;
  if (c == nullptr) {
    // Nothing to do
  } else if (!is_manual && c->IsTrivialMove()) {
    // Move file to next level
    assert(c->num_input_files(0) == 1);
    FileMetaData* f = c->input(0, 0);
    c->edit()->RemoveFile(c->level(), f->number);
    c->edit()->AddFile(c->level() + 1, f->number, f->file_size, f->smallest,
                       f->largest, f->has_range_dels);
    status = cf->versions->LogAndApply(c->edit(), &mutex_);
    if (!status.ok()) {
      RecordBackgroundError(status);
    }
    VersionSet::LevelSummaryStorage tmp;
    Log(db_options_.info_log, "Moved #%lld to level-%d %lld bytes %s: %s\n",
        static_cast<unsigned long long>(f->number), c->level() + 1,
        static_cast<unsigned long long>(f->file_size),
        status.ToString().c_str(), cf->versions->LevelSummary(&tmp));
  } else {
    CompactionState* compact = new CompactionState(c);
    compact->cf = cf;
    status = DoCompactionWork(compact);
    if (!status.ok()) {
      RecordBackgroundError(status);
    }
    CleanupCompaction(compact);
    c->ReleaseInputs();
    RemoveObsoleteFiles();
  }
  delete c;

  if (status.ok()) {
    // Done
  } else if (shutting_down_.load(std::memory_order_acquire)) {
    // Ignore compaction errors found during shutting down
  } else {
    Log(db_options_.info_log, "Compaction error: %s", status.ToString().c_str());
  }

  if (is_manual) {
    ManualCompaction* m = cf->manual;
    if (!status.ok()) {
      m->done = true;
    }
    if (!m->done) {
      // We only compacted part of the requested range.  Update *m
      // to the range that is left to be compacted.
      m->tmp_storage = manual_end;
      m->begin = &m->tmp_storage;
    }
    cf->manual = nullptr;
  }
}

void DBImpl::CleanupCompaction(CompactionState* compact) {
  ColumnFamily* cf = compact->cf;
  mutex_.AssertHeld();
  if (compact->builder != nullptr) {
    // May happen if we get a shutdown call in the middle of compaction
    compact->builder->Abandon();
    delete compact->builder;
  } else {
    assert(compact->outfile == nullptr);
  }
  delete compact->outfile;
  for (size_t i = 0; i < compact->outputs.size(); i++) {
    const CompactionState::Output& out = compact->outputs[i];
    cf->pending_outputs.erase(out.number);
  }
  delete compact;
}

Status DBImpl::OpenCompactionOutputFile(CompactionState* compact) {
  ColumnFamily* cf = compact->cf;
  assert(compact != nullptr);
  assert(compact->builder == nullptr);
  uint64_t file_number;
  {
    mutex_.Lock();
    file_number = cf->versions->NewFileNumber();
    cf->pending_outputs.insert(file_number);
    CompactionState::Output out;
    out.number = file_number;
    out.smallest.Clear();
    out.largest.Clear();
    compact->outputs.push_back(out);
    mutex_.Unlock();
  }

  // Make the output file
  std::string fname = TableFileName(cf->dir, file_number);
  Status s = env_->NewWritableFile(fname, &compact->outfile);
  if (s.ok()) {
    compact->builder = new TableBuilder(cf->options, compact->outfile);
  }
  return s;
}

Status DBImpl::FinishCompactionOutputFile(CompactionState* compact,
                                          Iterator* input,
                                          const Slice* upper_cut) {
  ColumnFamily* cf = compact->cf;
  assert(compact != nullptr);
  assert(compact->outfile != nullptr);
  assert(compact->builder != nullptr);

  const uint64_t output_number = compact->current_output()->number;
  assert(output_number != 0);

  // The tombstones this file carries: those parts of them in
  // [lower_cut, upper_cut).
  const Comparator* ucmp = cf->user_comparator();
  std::vector<RangeTombstone> mine;
  for (const RangeTombstone& t : compact->tombstones) {
    Slice b(t.begin), e(t.end);
    if (compact->has_lower_cut && ucmp->Compare(b, compact->lower_cut) < 0) {
      b = compact->lower_cut;
    }
    if (upper_cut != nullptr && ucmp->Compare(e, *upper_cut) > 0) {
      e = *upper_cut;
    }
    if (ucmp->Compare(b, e) < 0) {
      mine.emplace_back(b, e, t.seq);
    }
  }
  if (!mine.empty()) {
    std::string block;
    EncodeRangeTombstones(mine, &block);
    compact->builder->SetRangeDeletionBlock(block);
    CompactionState::Output* out = compact->current_output();
    AddTombstoneBounds(cf->icmp, mine,
                       compact->builder->NumEntries() > 0, &out->smallest,
                       &out->largest);
    out->has_range_dels = true;
  }
  if (upper_cut != nullptr) {
    compact->lower_cut = upper_cut->ToString();
    compact->has_lower_cut = true;
  }

  // Check for iterator errors
  Status s = input->status();
  const uint64_t current_entries = compact->builder->NumEntries();
  if (s.ok()) {
    s = compact->builder->Finish();
  } else {
    compact->builder->Abandon();
  }
  const uint64_t current_bytes = compact->builder->FileSize();
  compact->current_output()->file_size = current_bytes;
  compact->total_bytes += current_bytes;
  delete compact->builder;
  compact->builder = nullptr;

  // Finish and check for file errors
  if (s.ok()) {
    s = compact->outfile->Sync();
  }
  if (s.ok()) {
    s = compact->outfile->Close();
  }
  delete compact->outfile;
  compact->outfile = nullptr;

  if (s.ok() && current_entries > 0) {
    // Verify that the table is usable
    Iterator* iter =
        cf->table_cache->NewIterator(ReadOptions(), output_number, current_bytes);
    s = iter->status();
    delete iter;
    if (s.ok()) {
      Log(db_options_.info_log, "Generated table #%llu@%d: %lld keys, %lld bytes",
          (unsigned long long)output_number, compact->compaction->level(),
          (unsigned long long)current_entries,
          (unsigned long long)current_bytes);
    }
  }
  return s;
}

Status DBImpl::InstallCompactionResults(CompactionState* compact) {
  ColumnFamily* cf = compact->cf;
  mutex_.AssertHeld();
  Log(db_options_.info_log, "Compacted %d@%d + %d@%d files => %lld bytes",
      compact->compaction->num_input_files(0), compact->compaction->level(),
      compact->compaction->num_input_files(1), compact->compaction->level() + 1,
      static_cast<long long>(compact->total_bytes));

  // Add compaction outputs
  compact->compaction->AddInputDeletions(compact->compaction->edit());
  const int level = compact->compaction->level();
  for (size_t i = 0; i < compact->outputs.size(); i++) {
    const CompactionState::Output& out = compact->outputs[i];
    compact->compaction->edit()->AddFile(level + 1, out.number, out.file_size,
                                         out.smallest, out.largest,
                                         out.has_range_dels);
  }
  return cf->versions->LogAndApply(compact->compaction->edit(), &mutex_);
}

Status DBImpl::DoCompactionWork(CompactionState* compact) {
  ColumnFamily* cf = compact->cf;
  const uint64_t start_micros = env_->NowMicros();
  int64_t imm_micros = 0;  // Micros spent flushing memtables

  Log(db_options_.info_log, "Compacting %d@%d + %d@%d files",
      compact->compaction->num_input_files(0), compact->compaction->level(),
      compact->compaction->num_input_files(1),
      compact->compaction->level() + 1);

  assert(cf->versions->NumLevelFiles(compact->compaction->level()) > 0);
  assert(compact->builder == nullptr);
  assert(compact->outfile == nullptr);
  // Every live snapshot, oldest first.  Entries between two consecutive
  // snapshots (a "stripe") are seen by the same readers, so within a stripe
  // only what the newest of them resolves to has to be kept.
  std::vector<SequenceNumber> snapshots;
  snapshots_.GetAll(&snapshots);
  if (snapshots_.empty()) {
    compact->smallest_snapshot = cf->versions->LastSequence();
  } else {
    compact->smallest_snapshot = snapshots_.oldest()->sequence_number();
  }

  Iterator* input = cf->versions->MakeInputIterator(compact->compaction);

  // Release mutex while we're actually doing the compaction work
  mutex_.Unlock();

  const Comparator* ucmp = cf->user_comparator();
  Status status;

  // The range tombstones of the input files.  Those that nothing below the
  // output level can still need, and that every reader already sees, are
  // dropped; the rest go to the outputs.
  std::vector<RangeTombstone> input_tombstones;
  for (int which = 0; which < 2 && status.ok(); which++) {
    for (int i = 0; i < compact->compaction->num_input_files(which); i++) {
      FileMetaData* f = compact->compaction->input(which, i);
      if (!f->has_range_dels) continue;
      status = cf->table_cache->GetRangeTombstones(f->number, f->file_size,
                                                &input_tombstones);
      if (!status.ok()) break;
    }
  }
  RangeDelIndex input_rd(ucmp);
  for (const RangeTombstone& t : input_tombstones) {
    input_rd.Add(t);
    if (t.seq <= compact->smallest_snapshot &&
        compact->compaction->IsBaseLevelForRange(t.begin, t.end)) {
      continue;
    }
    compact->tombstones.push_back(t);
  }
  input_rd.Finish();
  std::sort(compact->tombstones.begin(), compact->tombstones.end(),
            [ucmp](const RangeTombstone& a, const RangeTombstone& b) {
              return ucmp->Compare(a.begin, b.begin) < 0;
            });

  // Stripe of a sequence number: index of the oldest snapshot at or above
  // it, snapshots.size() for the newest stripe.
  auto stripe_of = [&snapshots](SequenceNumber seq) -> size_t {
    return std::lower_bound(snapshots.begin(), snapshots.end(), seq) -
           snapshots.begin();
  };
  const MergeOperator* merge_op = cf->options.merge_operator;

  struct Entry {
    SequenceNumber seq;
    ValueType type;
    std::string value;
  };
  std::string group_key;             // user key of the group being collected
  std::vector<Entry> group;          // its entries, newest first
  std::vector<Entry> out;            // what the group compacts to
  bool pending_cut = false;          // current output is full

  // Writes one internal key to the outputs, opening a file if need be.
  auto emit = [&](const Slice& ikey, const Slice& value) -> Status {
    Status st;
    if (compact->builder == nullptr) {
      st = OpenCompactionOutputFile(compact);
      if (!st.ok()) return st;
    }
    if (compact->builder->NumEntries() == 0) {
      compact->current_output()->smallest.DecodeFrom(ikey);
    }
    compact->current_output()->largest.DecodeFrom(ikey);
    compact->builder->Add(ikey, value);
    return st;
  };

  // Compacts the collected group into `out` (newest first).
  auto compact_group = [&]() {
    out.clear();
    const Slice user_key(group_key);
    const bool base_level = compact->compaction->IsBaseLevelForKey(user_key);
    size_t i = 0;
    while (i < group.size()) {
      const size_t stripe = stripe_of(group[i].seq);
      const SequenceNumber bound =
          stripe < snapshots.size() ? snapshots[stripe] : kMaxSequenceNumber;
      const SequenceNumber newest = group[i].seq;
      std::vector<std::string> ops;  // newest first
      bool settled = false;
      const std::string* base = nullptr;
      size_t j = i;
      for (; j < group.size() && stripe_of(group[j].seq) == stripe; j++) {
        Entry& e = group[j];
        if (e.type != kTypeDeletion && input_rd.Covers(user_key, e.seq, bound)) {
          // Hidden by a tombstone that every reader of this stripe sees.
          e.type = kTypeDeletion;
          e.value.clear();
        }
        if (e.type == kTypeMerge) {
          ops.push_back(e.value);
          continue;
        }
        settled = true;
        if (e.type == kTypeValue) base = &e.value;
        break;
      }
      const size_t settle = j;  // index of the settling entry, if settled
      size_t next = j;
      while (next < group.size() && stripe_of(group[next].seq) == stripe) {
        next++;  // older entries of the stripe are hidden from everyone
      }
      const bool nothing_older = next >= group.size() && base_level;
      bool done = false;
      if (settled && ops.empty()) {
        const Entry& e = group[settle];
        if (e.type == kTypeDeletion && stripe == 0 && base_level) {
          // An obsolete deletion marker: nothing older anywhere.
        } else {
          out.push_back(e);
        }
        done = true;
      } else if (merge_op != nullptr && (settled || nothing_older)) {
        std::vector<std::string> oldest_first(ops.rbegin(), ops.rend());
        std::string merged;
        Slice base_slice;
        if (base != nullptr) base_slice = *base;
        if (merge_op->FullMerge(user_key, base != nullptr ? &base_slice : nullptr,
                                oldest_first, &merged)) {
          out.push_back(Entry{newest, kTypeValue, std::move(merged)});
          done = true;
        }
      } else if (merge_op != nullptr && ops.size() > 1) {
        std::string acc = ops.back();
        bool ok = true;
        for (size_t k = ops.size() - 1; k-- > 0;) {
          std::string tmp;
          if (!merge_op->PartialMerge(user_key, acc, ops[k], &tmp)) {
            ok = false;
            break;
          }
          acc.swap(tmp);
        }
        if (ok) {
          out.push_back(Entry{newest, kTypeMerge, std::move(acc)});
          done = true;
        }
      }
      if (!done) {
        // Keep the operands as they are, plus what settles them.
        for (size_t k = i; k < settle && k < group.size(); k++) {
          out.push_back(group[k]);
        }
        if (settled) out.push_back(group[settle]);
      }
      i = next;
    }
  };

  // Writes the compacted group, starting a new output file first if the
  // current one is full or should stop before this key.
  auto flush_group = [&]() -> Status {
    Status st;
    if (group.empty()) return st;
    std::string first_ikey;
    AppendInternalKey(&first_ikey,
                      ParsedInternalKey(group_key, group[0].seq, group[0].type));
    const bool stop = compact->compaction->ShouldStopBefore(first_ikey);
    compact_group();
    if (compact->builder != nullptr && (pending_cut || stop)) {
      Slice cut(group_key);
      st = FinishCompactionOutputFile(compact, input, &cut);
      pending_cut = false;
      if (!st.ok()) return st;
    }
    std::string ikey;
    for (const Entry& e : out) {
      ikey.clear();
      AppendInternalKey(&ikey, ParsedInternalKey(group_key, e.seq, e.type));
      st = emit(ikey, e.value);
      if (!st.ok()) return st;
    }
    if (compact->builder != nullptr &&
        compact->builder->FileSize() >=
            compact->compaction->MaxOutputFileSize()) {
      pending_cut = true;
    }
    group.clear();
    return st;
  };

  if (status.ok()) input->SeekToFirst();
  ParsedInternalKey ikey;
  while (status.ok() && input->Valid() &&
         !shutting_down_.load(std::memory_order_acquire)) {
    // Prioritize immutable compaction work
    if (pending_flush_.load(std::memory_order_relaxed)) {
      const uint64_t imm_start = env_->NowMicros();
      mutex_.Lock();
      for (const auto& entry : cfs_) {
        if (!entry.second->dropped && entry.second->imm != nullptr) {
          CompactMemTable(entry.second);
        }
      }
      // Wake up MakeRoomForWrite() if necessary.
      background_work_finished_signal_.SignalAll();
      mutex_.Unlock();
      imm_micros += (env_->NowMicros() - imm_start);
    }

    Slice key = input->key();
    if (!ParseInternalKey(key, &ikey) || ikey.type == kTypeRangeDeletion) {
      // Do not hide error keys
      status = flush_group();
      if (status.ok()) status = emit(key, input->value());
      group_key.clear();
    } else {
      if (!group.empty() && ucmp->Compare(ikey.user_key, group_key) != 0) {
        status = flush_group();
      }
      if (group.empty()) {
        group_key.assign(ikey.user_key.data(), ikey.user_key.size());
      }
      group.push_back(Entry{ikey.sequence, ikey.type, input->value().ToString()});
    }
    input->Next();
  }
  if (status.ok() && !shutting_down_.load(std::memory_order_acquire)) {
    status = flush_group();
  }

  if (status.ok() && shutting_down_.load(std::memory_order_acquire)) {
    status = Status::IOError("Deleting DB during compaction");
  }
  if (status.ok() && compact->builder == nullptr) {
    // Tombstones past the last output still need a home.
    bool left = false;
    for (const RangeTombstone& t : compact->tombstones) {
      if (!compact->has_lower_cut || ucmp->Compare(t.end, compact->lower_cut) > 0) {
        left = true;
        break;
      }
    }
    if (left) status = OpenCompactionOutputFile(compact);
  }
  if (status.ok() && compact->builder != nullptr) {
    status = FinishCompactionOutputFile(compact, input, nullptr);
  }
  if (status.ok()) {
    status = input->status();
  }
  delete input;
  input = nullptr;

  CompactionStats stats;
  stats.micros = env_->NowMicros() - start_micros - imm_micros;
  for (int which = 0; which < 2; which++) {
    for (int i = 0; i < compact->compaction->num_input_files(which); i++) {
      stats.bytes_read += compact->compaction->input(which, i)->file_size;
    }
  }
  for (size_t i = 0; i < compact->outputs.size(); i++) {
    stats.bytes_written += compact->outputs[i].file_size;
  }

  mutex_.Lock();
  cf->stats[compact->compaction->level() + 1].Add(stats);

  if (status.ok()) {
    status = InstallCompactionResults(compact);
  }
  if (!status.ok()) {
    RecordBackgroundError(status);
  }
  VersionSet::LevelSummaryStorage tmp;
  Log(db_options_.info_log, "compacted to: %s", cf->versions->LevelSummary(&tmp));
  return status;
}

namespace {

struct IterState {
  port::Mutex* const mu;
  Version* const version GUARDED_BY(mu);
  MemTable* const mem GUARDED_BY(mu);
  MemTable* const imm GUARDED_BY(mu);

  IterState(port::Mutex* mutex, MemTable* mem, MemTable* imm, Version* version)
      : mu(mutex), version(version), mem(mem), imm(imm) {}
};

static void CleanupIteratorState(void* arg1, void* arg2) {
  IterState* state = reinterpret_cast<IterState*>(arg1);
  state->mu->Lock();
  state->mem->Unref();
  if (state->imm != nullptr) state->imm->Unref();
  state->version->Unref();
  state->mu->Unlock();
  delete state;
}

}  // anonymous namespace

std::shared_ptr<const RangeDelView> DBImpl::RangeDelsLocked(ColumnFamily* cf,
                                                            MemTable* mem,
                                                            MemTable* imm,
                                                            Version* v,
                                                            Status* s) {
  mutex_.AssertHeld();
  RangeDelCache& c = cf->rd_cache;
  if (c.version_id != v->id()) {
    c.version_id = v->id();
    c.version_has_range_dels = v->HasRangeDels();
    c.index.reset();
    if (c.version_has_range_dels) {
      std::vector<RangeTombstone> all;
      *s = v->GetRangeTombstones(&all);
      if (!s->ok()) {
        c.version_id = 0;
        return nullptr;
      }
      RangeDelIndex* index = new RangeDelIndex(cf->user_comparator());
      for (const RangeTombstone& t : all) index->Add(t);
      index->Finish();
      c.index.reset(index);
    }
  }
  if (mem->NumRangeTombstones() == 0 &&
      (imm == nullptr || imm->NumRangeTombstones() == 0) && c.index == nullptr) {
    return nullptr;
  }
  return std::make_shared<const RangeDelView>(mem, imm, c.index);
}

Iterator* DBImpl::NewInternalIterator(
    const ReadOptions& options, ColumnFamily* cf,
    SequenceNumber* latest_snapshot, uint32_t* seed,
    std::shared_ptr<const RangeDelView>* range_dels) {
  mutex_.Lock();
  *latest_snapshot = last_sequence_;
  std::shared_ptr<const RangeDelView> view;
  if (range_dels != nullptr) {
    Status s;
    view = RangeDelsLocked(cf, cf->mem, cf->imm, cf->versions->current(), &s);
    if (!s.ok()) {
      mutex_.Unlock();
      return NewErrorIterator(s);
    }
    *range_dels = view;
  }

  // Collect together all needed child iterators
  std::vector<Iterator*> list;
  list.push_back(cf->mem->NewIterator());
  cf->mem->Ref();
  if (cf->imm != nullptr) {
    list.push_back(cf->imm->NewIterator());
    cf->imm->Ref();
  }
  if (view == nullptr) {
    cf->versions->current()->AddIterators(options, &list);
  } else {
    // Each older layer skips what a newer layer's tombstone hides.
    const SequenceNumber snapshot =
        options.snapshot != nullptr
            ? static_cast<const SnapshotImpl*>(options.snapshot)
                  ->sequence_number()
            : *latest_snapshot;
    if (cf->imm != nullptr) {
      list.back() = NewRangeDelSkippingIterator(list.back(), &cf->icmp,
                                                view, kLayerImm, snapshot);
    }
    std::vector<std::pair<Iterator*, int>> layers;
    cf->versions->current()->AddLayerIterators(options, &layers);
    for (auto& p : layers) {
      list.push_back(NewRangeDelSkippingIterator(p.first, &cf->icmp,
                                                 view, p.second, snapshot));
    }
  }
  Iterator* internal_iter =
      NewMergingIterator(&cf->icmp, &list[0], list.size());
  cf->versions->current()->Ref();

  IterState* cleanup = new IterState(&mutex_, cf->mem, cf->imm, cf->versions->current());
  internal_iter->RegisterCleanup(CleanupIteratorState, cleanup, nullptr);

  *seed = ++seed_;
  mutex_.Unlock();
  return internal_iter;
}

Iterator* DBImpl::TEST_NewInternalIterator() {
  SequenceNumber ignored;
  uint32_t ignored_seed;
  return NewInternalIterator(ReadOptions(), default_cf_, &ignored, &ignored_seed);
}

int64_t DBImpl::TEST_MaxNextLevelOverlappingBytes() {
  MutexLock l(&mutex_);
  return default_cf_->versions->MaxNextLevelOverlappingBytes();
}

Status DBImpl::Get(const ReadOptions& options, const Slice& key,
                   std::string* value) {
  return Get(options, nullptr, key, value);
}

Status DBImpl::Get(const ReadOptions& options, ColumnFamilyHandle* handle,
                   const Slice& key, std::string* value) {
  MutexLock l(&mutex_);
  ColumnFamily* cf = nullptr;
  Status s = CheckFamily(handle, &cf);
  if (!s.ok()) return s;
  SequenceNumber snapshot;
  if (options.snapshot != nullptr) {
    snapshot =
        static_cast<const SnapshotImpl*>(options.snapshot)->sequence_number();
  } else {
    snapshot = last_sequence_;
  }

  MemTable* mem = cf->mem;
  MemTable* imm = cf->imm;
  Version* current = cf->versions->current();
  mem->Ref();
  if (imm != nullptr) imm->Ref();
  current->Ref();

  bool have_stat_update = false;
  Version::GetStats stats;
  std::shared_ptr<const RangeDelView> range_dels =
      RangeDelsLocked(cf, mem, imm, current, &s);

  // Unlock while reading from files and memtables
  if (s.ok()) {
    mutex_.Unlock();
    // First look in the memtable, then in the immutable memtable (if any).
    LookupKey lkey(key, snapshot);
    LookupState lookup(key, snapshot, cf->options.merge_operator,
                       range_dels.get(), value);
    // A tombstone of a newer layer hides everything below it.
    auto hidden_below = [&](int layer) {
      if (range_dels != nullptr &&
          range_dels->MaxCovering(key, snapshot, layer) > 0) {
        lookup.SettleDeleted();
        return true;
      }
      return false;
    };
    if (mem->Get(lkey, &lookup)) {
      // Done
    } else if (imm != nullptr &&
               (hidden_below(kLayerImm) || imm->Get(lkey, &lookup))) {
      // Done
    } else if (hidden_below(kFirstTableLayer)) {
      // Done
    } else {
      s = current->Get(options, lkey, &lookup, &stats, range_dels.get());
      have_stat_update = true;
    }
    if (s.ok()) s = lookup.Finish();
    mutex_.Lock();
  }

  if (have_stat_update && current->UpdateStats(stats)) {
    MaybeScheduleCompaction();
  }
  mem->Unref();
  if (imm != nullptr) imm->Unref();
  current->Unref();
  return s;
}

Iterator* DBImpl::NewIterator(const ReadOptions& options) {
  return NewIterator(options, nullptr);
}

Iterator* DBImpl::NewIterator(const ReadOptions& options,
                              ColumnFamilyHandle* handle) {
  ColumnFamily* cf = nullptr;
  Status fs = CheckFamily(handle, &cf);
  if (!fs.ok()) return NewErrorIterator(fs);
  SequenceNumber latest_snapshot;
  uint32_t seed;
  std::shared_ptr<const RangeDelView> range_dels;
  Iterator* iter =
      NewInternalIterator(options, cf, &latest_snapshot, &seed, &range_dels);
  return NewDBIterator(this, cf->user_comparator(), iter,
                       (options.snapshot != nullptr
                            ? static_cast<const SnapshotImpl*>(options.snapshot)
                                  ->sequence_number()
                            : latest_snapshot),
                       seed, cf->options.merge_operator, std::move(range_dels));
}

void DBImpl::RecordReadSample(Slice key) {
  MutexLock l(&mutex_);
  if (default_cf_->versions->current()->RecordReadSample(key)) {
    MaybeScheduleCompaction();
  }
}

const Snapshot* DBImpl::GetSnapshot() {
  MutexLock l(&mutex_);
  return snapshots_.New(last_sequence_);
}

void DBImpl::ReleaseSnapshot(const Snapshot* snapshot) {
  MutexLock l(&mutex_);
  snapshots_.Delete(static_cast<const SnapshotImpl*>(snapshot));
}

// Convenience methods
Status DBImpl::Put(const WriteOptions& o, const Slice& key, const Slice& val) {
  return DB::Put(o, key, val);
}

Status DBImpl::Put(const WriteOptions& o, ColumnFamilyHandle* family,
                   const Slice& key, const Slice& val) {
  return DB::Put(o, family, key, val);
}

Status DBImpl::Delete(const WriteOptions& options, const Slice& key) {
  return DB::Delete(options, key);
}

Status DBImpl::Delete(const WriteOptions& options, ColumnFamilyHandle* family,
                      const Slice& key) {
  return DB::Delete(options, family, key);
}

Status DBImpl::DeleteRange(const WriteOptions& options, const Slice& begin,
                           const Slice& end) {
  return DB::DeleteRange(options, begin, end);
}

Status DBImpl::DeleteRange(const WriteOptions& options,
                           ColumnFamilyHandle* family, const Slice& begin,
                           const Slice& end) {
  return DB::DeleteRange(options, family, begin, end);
}

Status DBImpl::Merge(const WriteOptions& options, const Slice& key,
                     const Slice& value) {
  return Merge(options, nullptr, key, value);
}

Status DBImpl::Merge(const WriteOptions& options, ColumnFamilyHandle* family,
                     const Slice& key, const Slice& value) {
  {
    MutexLock l(&mutex_);
    ColumnFamily* cf = nullptr;
    Status s = CheckFamily(family, &cf);
    if (!s.ok()) return s;
    if (cf->options.merge_operator == nullptr) {
      return Status::InvalidArgument("no merge_operator configured", cf->name);
    }
  }
  return DB::Merge(options, family, key, value);
}

Status DBImpl::Write(const WriteOptions& options, WriteBatch* updates) {
  // Which families does this batch touch, and do they all take operands?
  std::set<uint32_t> families, merges;
  if (updates != nullptr) {
    WriteBatchInternal::Scan(updates, &families, &merges);
    MutexLock l(&mutex_);
    for (uint32_t id : families) {
      auto it = cfs_.find(id);
      if (it == cfs_.end() || it->second->dropped) {
        return Status::InvalidArgument("no such column family",
                                       std::to_string(id));
      }
      if (merges.count(id) && it->second->options.merge_operator == nullptr) {
        return Status::InvalidArgument("no merge_operator configured",
                                       it->second->name);
      }
    }
  }

  Writer w(&mutex_);
  w.batch = updates;
  w.sync = options.sync;
  w.done = false;

  MutexLock l(&mutex_);
  writers_.push_back(&w);
  while (!w.done && &w != writers_.front()) {
    w.cv.Wait();
  }
  if (w.done) {
    return w.status;
  }

  // May temporarily unlock and wait.
  Status status = MakeRoomForWrite(families, updates == nullptr);
  uint64_t last_sequence = last_sequence_;
  Writer* last_writer = &w;
  if (status.ok() && updates != nullptr) {  // nullptr batch is for compactions
    WriteBatch* write_batch = BuildBatchGroup(&last_writer);
    WriteBatchInternal::SetSequence(write_batch, last_sequence + 1);
    last_sequence += WriteBatchInternal::Count(write_batch);

    // Every live family's memtable, so each record goes to its own.
    std::map<uint32_t, MemTable*> mems;
    for (const auto& entry : cfs_) {
      if (!entry.second->dropped) mems[entry.first] = entry.second->mem;
    }

    // Add to log and apply to the memtables.  We can release the lock
    // during this phase since &w is currently responsible for logging
    // and protects against concurrent loggers and concurrent writes
    // into the memtables.
    {
      mutex_.Unlock();
      status = log_->AddRecord(WriteBatchInternal::Contents(write_batch));
      bool sync_error = false;
      if (status.ok() && options.sync) {
        status = logfile_->Sync();
        if (!status.ok()) {
          sync_error = true;
        }
      }
      if (status.ok()) {
        status = WriteBatchInternal::InsertInto(write_batch, mems);
      }
      mutex_.Lock();
      if (sync_error) {
        // The state of the log file is indeterminate: the log record we
        // just added may or may not show up when the DB is re-opened.
        // So we force the DB into a mode where all future writes fail.
        RecordBackgroundError(status);
      }
    }
    if (write_batch == tmp_batch_) tmp_batch_->Clear();

    last_sequence_ = last_sequence;
    // Each family's manifest records the sequence it last saw, so a reopen
    // can take the largest of them.
    for (const auto& entry : cfs_) {
      entry.second->versions->SetLastSequence(last_sequence);
    }
  }

  while (true) {
    Writer* ready = writers_.front();
    writers_.pop_front();
    if (ready != &w) {
      ready->status = status;
      ready->done = true;
      ready->cv.Signal();
    }
    if (ready == last_writer) break;
  }

  // Notify new head of write queue
  if (!writers_.empty()) {
    writers_.front()->cv.Signal();
  }

  return status;
}

// REQUIRES: Writer list must be non-empty
// REQUIRES: First writer must have a non-null batch
WriteBatch* DBImpl::BuildBatchGroup(Writer** last_writer) {
  mutex_.AssertHeld();
  assert(!writers_.empty());
  Writer* first = writers_.front();
  WriteBatch* result = first->batch;
  assert(result != nullptr);

  size_t size = WriteBatchInternal::ByteSize(first->batch);

  // Allow the group to grow up to a maximum size, but if the
  // original write is small, limit the growth so we do not slow
  // down the small write too much.
  size_t max_size = 1 << 20;
  if (size <= (128 << 10)) {
    max_size = size + (128 << 10);
  }

  *last_writer = first;
  std::deque<Writer*>::iterator iter = writers_.begin();
  ++iter;  // Advance past "first"
  for (; iter != writers_.end(); ++iter) {
    Writer* w = *iter;
    if (w->sync && !first->sync) {
      // Do not include a sync write into a batch handled by a non-sync write.
      break;
    }

    if (w->batch != nullptr) {
      size += WriteBatchInternal::ByteSize(w->batch);
      if (size > max_size) {
        // Do not make batch too big
        break;
      }

      // Append to *result
      if (result == first->batch) {
        // Switch to temporary batch instead of disturbing caller's batch
        result = tmp_batch_;
        assert(WriteBatchInternal::Count(result) == 0);
        WriteBatchInternal::Append(result, first->batch);
      }
      WriteBatchInternal::Append(result, w->batch);
    }
    *last_writer = w;
  }
  return result;
}

// REQUIRES: mutex_ is held
// REQUIRES: this thread is currently at the front of the writer queue
Status DBImpl::SwitchLog() {
  mutex_.AssertHeld();
  // Log numbers come from the default family's file numbers: the logs live
  // in the database directory, which is that family's own.
  uint64_t new_log_number = default_cf_->versions->NewFileNumber();
  WritableFile* lfile = nullptr;
  Status s = env_->NewWritableFile(LogFileName(dbname_, new_log_number), &lfile);
  if (!s.ok()) {
    // Avoid chewing through file number space in a tight loop.
    default_cf_->versions->ReuseFileNumber(new_log_number);
    return s;
  }
  delete log_;
  delete logfile_;
  logfile_ = lfile;
  logfile_number_ = new_log_number;
  log_ = new log::Writer(lfile);
  return s;
}

Status DBImpl::MakeRoomForWrite(const std::set<uint32_t>& families, bool force) {
  mutex_.AssertHeld();
  assert(!writers_.empty());
  bool allow_delay = !force;
  Status s;
  // The families the batch touches, plus any that is holding an old log
  // back: those have to be flushed so the log can be deleted.
  while (true) {
    if (!bg_error_.ok()) {
      // Yield previous error
      s = bg_error_;
      break;
    }
    // Pick a family that needs room.  `force` (a null batch) applies to the
    // default family, as it always did.
    ColumnFamily* cf = nullptr;
    bool over_l0_soft = false, over_l0_hard = false, waiting = false;
    std::set<uint32_t> want = families;
    if (force) want.insert(0);
    // Families lagging far behind on the shared log are flushed too, so
    // that old logs can go.
    const uint64_t oldest = OldestLiveLog();
    if (logfile_number_ > oldest + kMaxLiveLogs) {
      for (const auto& entry : cfs_) {
        ColumnFamily* candidate = entry.second;
        if (candidate->dropped || candidate->imm != nullptr) continue;
        if (candidate->mem_log_number <= oldest) want.insert(entry.first);
      }
    }
    for (uint32_t id : want) {
      auto it = cfs_.find(id);
      if (it == cfs_.end() || it->second->dropped) continue;
      ColumnFamily* candidate = it->second;
      const bool full =
          (force && candidate == default_cf_) ||
          candidate->mem == nullptr ||
          candidate->mem->ApproximateMemoryUsage() >
              candidate->options.write_buffer_size ||
          (candidate->mem_log_number <= oldest &&
           logfile_number_ > oldest + kMaxLiveLogs && candidate->mem->ApproximateMemoryUsage() > 0);
      if (!full) {
        if (allow_delay && candidate->versions->NumLevelFiles(0) >=
                               config::kL0_SlowdownWritesTrigger) {
          over_l0_soft = true;
        }
        continue;
      }
      if (candidate->imm != nullptr) {
        waiting = true;  // its previous memtable is still being flushed
        continue;
      }
      if (candidate->versions->NumLevelFiles(0) >=
          config::kL0_StopWritesTrigger) {
        over_l0_hard = true;
        continue;
      }
      cf = candidate;
      break;
    }
    if (cf == nullptr && over_l0_soft) {
      // We are getting close to hitting a hard limit on the number of
      // L0 files.  Rather than delaying a single write by several
      // seconds when we hit the hard limit, start delaying each
      // individual write by 1ms to reduce latency variance.  Also,
      // this delay hands over some CPU to the compaction thread in
      // case it is sharing the same core as the writer.
      mutex_.Unlock();
      env_->SleepForMicroseconds(1000);
      allow_delay = false;  // Do not delay a single write more than once
      mutex_.Lock();
      continue;
    }
    if (cf == nullptr && (waiting || over_l0_hard)) {
      Log(db_options_.info_log, "Waiting for background work\n");
      background_work_finished_signal_.Wait();
      continue;
    }
    if (cf == nullptr) {
      break;  // every family the batch touches has room
    }
    // Attempt to switch to a new memtable and trigger a flush of the old.
    // The new memtable writes to a new log, so the old one can be deleted
    // once every family that used it has flushed.
    assert(cf->versions->PrevLogNumber() == 0);
    s = SwitchLog();
    if (!s.ok()) break;
    cf->imm = cf->mem;
    cf->imm_log_number = cf->mem_log_number;
    cf->has_imm.store(true, std::memory_order_release);
    pending_flush_.store(true, std::memory_order_release);
    cf->mem = new MemTable(cf->icmp);
    cf->mem->Ref();
    cf->mem_log_number = logfile_number_;
    force = false;  // Do not force another compaction if have room
    MaybeScheduleCompaction();
  }
  return s;
}

bool DBImpl::GetProperty(const Slice& property, std::string* value) {
  return GetProperty(nullptr, property, value);
}

bool DBImpl::GetProperty(ColumnFamilyHandle* handle, const Slice& property,
                         std::string* value) {
  value->clear();

  MutexLock l(&mutex_);
  ColumnFamily* cf = nullptr;
  if (!CheckFamily(handle, &cf).ok()) return false;
  Slice in = property;
  Slice prefix("leveldb.");
  if (!in.starts_with(prefix)) return false;
  in.remove_prefix(prefix.size());

  if (in.starts_with("num-files-at-level")) {
    in.remove_prefix(strlen("num-files-at-level"));
    uint64_t level;
    bool ok = ConsumeDecimalNumber(&in, &level) && in.empty();
    if (!ok || level >= config::kNumLevels) {
      return false;
    } else {
      char buf[100];
      std::snprintf(buf, sizeof(buf), "%d",
                    cf->versions->NumLevelFiles(static_cast<int>(level)));
      *value = buf;
      return true;
    }
  } else if (in == "stats") {
    char buf[200];
    std::snprintf(buf, sizeof(buf),
                  "                               Compactions\n"
                  "Level  Files Size(MB) Time(sec) Read(MB) Write(MB)\n"
                  "--------------------------------------------------\n");
    value->append(buf);
    for (int level = 0; level < config::kNumLevels; level++) {
      int files = cf->versions->NumLevelFiles(level);
      if (cf->stats[level].micros > 0 || files > 0) {
        std::snprintf(buf, sizeof(buf), "%3d %8d %8.0f %9.0f %8.0f %9.0f\n",
                      level, files, cf->versions->NumLevelBytes(level) / 1048576.0,
                      cf->stats[level].micros / 1e6,
                      cf->stats[level].bytes_read / 1048576.0,
                      cf->stats[level].bytes_written / 1048576.0);
        value->append(buf);
      }
    }
    return true;
  } else if (in == "sstables") {
    *value = cf->versions->current()->DebugString();
    return true;
  } else if (in == "approximate-memory-usage") {
    size_t total_usage = cf->options.block_cache->TotalCharge();
    if (cf->mem) {
      total_usage += cf->mem->ApproximateMemoryUsage();
    }
    if (cf->imm) {
      total_usage += cf->imm->ApproximateMemoryUsage();
    }
    char buf[50];
    std::snprintf(buf, sizeof(buf), "%llu",
                  static_cast<unsigned long long>(total_usage));
    value->append(buf);
    return true;
  }

  return false;
}

void DBImpl::GetApproximateSizes(const Range* range, int n, uint64_t* sizes) {
  // TODO(opt): better implementation
  MutexLock l(&mutex_);
  ColumnFamily* cf = default_cf_;
  Version* v = cf->versions->current();
  v->Ref();

  for (int i = 0; i < n; i++) {
    // Convert user_key into a corresponding internal key.
    InternalKey k1(range[i].start, kMaxSequenceNumber, kValueTypeForSeek);
    InternalKey k2(range[i].limit, kMaxSequenceNumber, kValueTypeForSeek);
    uint64_t start = cf->versions->ApproximateOffsetOf(v, k1);
    uint64_t limit = cf->versions->ApproximateOffsetOf(v, k2);
    sizes[i] = (limit >= start ? limit - start : 0);
  }

  v->Unref();
}

// Default implementations of convenience methods that subclasses of DB
// can call if they wish
Status DB::Put(const WriteOptions& opt, const Slice& key, const Slice& value) {
  WriteBatch batch;
  batch.Put(key, value);
  return Write(opt, &batch);
}

Status DB::Delete(const WriteOptions& opt, const Slice& key) {
  WriteBatch batch;
  batch.Delete(key);
  return Write(opt, &batch);
}

Status DB::DeleteRange(const WriteOptions& opt, const Slice& begin,
                       const Slice& end) {
  WriteBatch batch;
  batch.DeleteRange(begin, end);
  return Write(opt, &batch);
}

Status DB::Merge(const WriteOptions& opt, const Slice& key,
                 const Slice& value) {
  WriteBatch batch;
  batch.Merge(key, value);
  return Write(opt, &batch);
}

// Column-family variants: the base class routes them through Write, so an
// engine only has to implement Write and Get.
Status DB::Put(const WriteOptions& opt, ColumnFamilyHandle* family,
               const Slice& key, const Slice& value) {
  WriteBatch batch;
  batch.Put(family, key, value);
  return Write(opt, &batch);
}

Status DB::Delete(const WriteOptions& opt, ColumnFamilyHandle* family,
                  const Slice& key) {
  WriteBatch batch;
  batch.Delete(family, key);
  return Write(opt, &batch);
}

Status DB::DeleteRange(const WriteOptions& opt, ColumnFamilyHandle* family,
                       const Slice& begin, const Slice& end) {
  WriteBatch batch;
  batch.DeleteRange(family, begin, end);
  return Write(opt, &batch);
}

Status DB::Merge(const WriteOptions& opt, ColumnFamilyHandle* family,
                 const Slice& key, const Slice& value) {
  WriteBatch batch;
  batch.Merge(family, key, value);
  return Write(opt, &batch);
}

Status DB::Get(const ReadOptions& options, ColumnFamilyHandle* family,
               const Slice& key, std::string* value) {
  if (family != nullptr && family->GetID() != 0) {
    return Status::NotSupported("column families");
  }
  return Get(options, key, value);
}

Iterator* DB::NewIterator(const ReadOptions& options,
                          ColumnFamilyHandle* family) {
  if (family != nullptr && family->GetID() != 0) {
    return NewErrorIterator(Status::NotSupported("column families"));
  }
  return NewIterator(options);
}

bool DB::GetProperty(ColumnFamilyHandle* family, const Slice& property,
                     std::string* value) {
  if (family != nullptr && family->GetID() != 0) return false;
  return GetProperty(property, value);
}

void DB::CompactRange(ColumnFamilyHandle* family, const Slice* begin,
                      const Slice* end) {
  if (family == nullptr || family->GetID() == 0) CompactRange(begin, end);
}

Status DB::CreateColumnFamily(const Options& options, const std::string& name,
                              ColumnFamilyHandle** handle) {
  return Status::NotSupported("column families");
}

Status DB::DropColumnFamily(ColumnFamilyHandle* handle) {
  return Status::NotSupported("column families");
}

Status DB::DestroyColumnFamilyHandle(ColumnFamilyHandle* handle) {
  return Status::NotSupported("column families");
}

ColumnFamilyHandle* DB::DefaultColumnFamily() const { return nullptr; }

DB::~DB() = default;

Status DBImpl::CreateColumnFamilyLocked(const Options& options,
                                        const std::string& name,
                                        ColumnFamilyHandle** handle) {
  mutex_.AssertHeld();
  if (name == kDefaultColumnFamilyName) {
    return Status::InvalidArgument("the default column family exists");
  }
  for (const auto& entry : cfs_) {
    if (!entry.second->dropped && entry.second->name == name) {
      return Status::InvalidArgument("column family exists", name);
    }
  }
  const uint32_t id = next_family_id_++;
  const std::string dir = ColumnFamilyDir(dbname_, id);
  // Ignore an error from CreateDir: the directory may be left over from a
  // crash, and the family is committed by its descriptor, not its directory.
  env_->CreateDir(dir);
  Status s = NewDB(dir);
  if (!s.ok()) return s;

  Options raw = options;
  raw.env = env_;
  raw.info_log = db_options_.info_log;
  raw.block_cache = db_options_.block_cache;
  raw.max_open_files = db_options_.max_open_files;
  raw.comparator = user_comparator_;
  ColumnFamily* cf = new ColumnFamily(id, name, dir, raw, user_comparator_);
  cf->options = SanitizeOptions(dir, &cf->icmp, &cf->ipolicy, raw);
  cf->options.info_log = db_options_.info_log;
  cf->options.block_cache = db_options_.block_cache;
  cf->refs = 1;
  bool save_manifest = false;
  VersionEdit edit;
  s = OpenColumnFamily(cf, &save_manifest, &edit);
  if (!s.ok()) {
    delete cf->versions;
    delete cf->table_cache;
    delete cf;
    return s;
  }
  cf->mem = new MemTable(cf->icmp);
  cf->mem->Ref();
  cf->mem_log_number = logfile_number_;
  // A new family starts at the current log: nothing older belongs to it.
  VersionEdit log_edit;
  log_edit.SetLogNumber(logfile_number_);
  log_edit.SetLastSequence(last_sequence_);
  s = cf->versions->LogAndApply(&log_edit, &mutex_);
  if (!s.ok()) {
    delete cf->versions;
    delete cf->table_cache;
    if (cf->mem != nullptr) cf->mem->Unref();
    delete cf;
    return s;
  }
  cfs_[id] = cf;

  // Record it, so a reopen finds it.
  std::vector<std::pair<uint32_t, std::string>> on_disk;
  for (const auto& entry : cfs_) {
    if (entry.first != 0 && !entry.second->dropped) {
      on_disk.emplace_back(entry.first, entry.second->name);
    }
  }
  s = WriteFamilies(env_, dbname_, on_disk, next_family_id_);
  if (!s.ok()) return s;
  cf->refs++;  // the handle below
  *handle = new ColumnFamilyHandleImpl(cf, this);
  return Status::OK();
}

Status DBImpl::CreateColumnFamily(const Options& options,
                                  const std::string& name,
                                  ColumnFamilyHandle** handle) {
  MutexLock l(&mutex_);
  return CreateColumnFamilyLocked(options, name, handle);
}

Status DBImpl::DropColumnFamily(ColumnFamilyHandle* handle) {
  MutexLock l(&mutex_);
  ColumnFamily* cf = nullptr;
  Status s = CheckFamily(handle, &cf);
  if (!s.ok()) return s;
  if (cf->id == 0) {
    return Status::InvalidArgument("the default column family cannot be dropped");
  }
  // Wait for background work on this family to finish, so nothing writes
  // into the directory while it is going away.
  while (background_compaction_scheduled_) {
    background_work_finished_signal_.Wait();
  }
  cf->dropped = true;
  if (cf->mem != nullptr) {
    cf->mem->Unref();
    cf->mem = nullptr;
  }
  if (cf->imm != nullptr) {
    cf->imm->Unref();
    cf->imm = nullptr;
    cf->has_imm.store(false, std::memory_order_release);
  }

  std::vector<std::pair<uint32_t, std::string>> on_disk;
  for (const auto& entry : cfs_) {
    if (entry.first != 0 && !entry.second->dropped) {
      on_disk.emplace_back(entry.first, entry.second->name);
    }
  }
  s = WriteFamilies(env_, dbname_, on_disk, next_family_id_);
  if (!s.ok()) return s;

  // Its files are nobody's now.
  const std::string dir = cf->dir;
  std::vector<std::string> filenames;
  mutex_.Unlock();
  env_->GetChildren(dir, &filenames);
  for (const std::string& filename : filenames) {
    if (filename == "." || filename == "..") continue;
    env_->RemoveFile(dir + "/" + filename);
  }
  env_->RemoveDir(dir);
  mutex_.Lock();
  return Status::OK();
}

Status DBImpl::DestroyColumnFamilyHandle(ColumnFamilyHandle* handle) {
  if (handle == nullptr) return Status::InvalidArgument("null handle");
  MutexLock l(&mutex_);
  ColumnFamilyHandleImpl* impl = static_cast<ColumnFamilyHandleImpl*>(handle);
  if (impl->db() != this) {
    return Status::InvalidArgument("column family of another database");
  }
  if (impl == default_handle_) return Status::OK();  // owned by the database
  ColumnFamily* cf = impl->cf();
  delete impl;
  if (--cf->refs <= 0 && cf->dropped) {
    cfs_.erase(cf->id);
    delete cf->versions;
    delete cf->table_cache;
    delete cf;
  }
  return Status::OK();
}

ColumnFamilyHandle* DBImpl::DefaultColumnFamily() const {
  return default_handle_;
}

Status DB::Open(const Options& options, const std::string& dbname, DB** dbptr) {
  std::vector<ColumnFamilyHandle*> handles;
  return DB::Open(options, dbname, std::vector<ColumnFamilyDescriptor>(),
                  &handles, dbptr);
}

Status DB::Open(const Options& db_options, const std::string& dbname,
                const std::vector<ColumnFamilyDescriptor>& families,
                std::vector<ColumnFamilyHandle*>* handles, DB** dbptr) {
  *dbptr = nullptr;
  if (handles != nullptr) handles->clear();

  DBImpl* impl = new DBImpl(db_options, dbname);
  impl->mutex_.Lock();
  // Recover handles create_if_missing, error_if_exists
  bool save_manifest = false;
  Status s = impl->Recover(families, db_options.create_missing_column_families,
                           &save_manifest);
  if (s.ok() && impl->log_ == nullptr) {
    // Create a new log; every family that has no memtable yet starts on it.
    s = impl->SwitchLog();
  }
  if (s.ok()) {
    for (const auto& entry : impl->cfs_) {
      ColumnFamily* cf = entry.second;
      if (cf->mem == nullptr) {
        cf->mem = new MemTable(cf->icmp);
        cf->mem->Ref();
        cf->mem_log_number = impl->logfile_number_;
      }
      auto it = impl->recovery_edits_.find(cf->id);
      const bool has_files = it != impl->recovery_edits_.end();
      if (save_manifest || has_files || cf->versions->LogNumber() == 0) {
        VersionEdit edit;
        if (has_files) edit = it->second;
        edit.SetPrevLogNumber(0);  // No older logs needed after recovery.
        // Everything below the log this family's memtable writes to is now
        // in its tables.
        edit.SetLogNumber(cf->mem_log_number);
        s = cf->versions->LogAndApply(&edit, &impl->mutex_);
        if (!s.ok()) break;
      }
    }
  }
  if (s.ok()) {
    impl->default_handle_ = new ColumnFamilyHandleImpl(impl->default_cf_, impl);
    impl->default_cf_->refs++;
    impl->RemoveObsoleteFiles();
    impl->MaybeScheduleCompaction();
  }
  if (s.ok() && handles != nullptr) {
    for (const ColumnFamilyDescriptor& d : families) {
      ColumnFamily* found = nullptr;
      for (const auto& entry : impl->cfs_) {
        if (!entry.second->dropped && entry.second->name == d.name) {
          found = entry.second;
          break;
        }
      }
      if (found == nullptr) {
        s = Status::InvalidArgument("column family does not exist", d.name);
        break;
      }
      if (found->id == 0) {
        handles->push_back(impl->default_handle_);
      } else {
        found->refs++;
        handles->push_back(new ColumnFamilyHandleImpl(found, impl));
      }
    }
  }
  impl->mutex_.Unlock();
  if (s.ok()) {
    assert(impl->default_cf_->mem != nullptr);
    *dbptr = impl;
  } else {
    if (handles != nullptr) handles->clear();
    delete impl;
  }
  return s;
}

Status DB::ListColumnFamilies(const Options& options, const std::string& name,
                              std::vector<std::string>* names) {
  names->clear();
  names->push_back(kDefaultColumnFamilyName);
  std::vector<std::pair<uint32_t, std::string>> families;
  uint32_t next_id = 1;
  Status s = ReadFamilies(options.env, name, &families, &next_id);
  if (!s.ok()) return s;
  for (const auto& f : families) names->push_back(f.second);
  return Status::OK();
}

Snapshot::~Snapshot() = default;

Status DestroyDB(const std::string& dbname, const Options& options) {
  Env* env = options.env;
  std::vector<std::string> filenames;
  Status result = env->GetChildren(dbname, &filenames);
  if (!result.ok()) {
    // Ignore error in case directory does not exist
    return Status::OK();
  }

  FileLock* lock;
  const std::string lockname = LockFileName(dbname);
  result = env->LockFile(lockname, &lock);
  if (result.ok()) {
    uint64_t number;
    FileType type;
    // The column families' directories first, then the database's own files.
    std::vector<std::pair<uint32_t, std::string>> families;
    uint32_t next_id = 1;
    ReadFamilies(env, dbname, &families, &next_id);
    for (const auto& f : families) {
      const std::string dir = ColumnFamilyDir(dbname, f.first);
      std::vector<std::string> names;
      if (!env->GetChildren(dir, &names).ok()) continue;
      for (const std::string& name : names) {
        if (name == "." || name == "..") continue;
        env->RemoveFile(dir + "/" + name);
      }
      env->RemoveDir(dir);
    }
    env->RemoveFile(FamiliesFileName(dbname));
    for (size_t i = 0; i < filenames.size(); i++) {
      if (ParseFileName(filenames[i], &number, &type) &&
          type != kDBLockFile) {  // Lock file will be deleted at end
        Status del = env->RemoveFile(dbname + "/" + filenames[i]);
        if (result.ok() && !del.ok()) {
          result = del;
        }
      }
    }
    env->UnlockFile(lock);  // Ignore error since state is already gone
    env->RemoveFile(lockname);
    env->RemoveDir(dbname);  // Ignore error in case dir contains other files
  }
  return result;
}

}  // namespace leveldb
