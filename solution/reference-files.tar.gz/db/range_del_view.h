// Copyright (c) 2011 The LevelDB Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file. See the AUTHORS file for names of contributors.
//
// What a read consults to find range tombstones: the memtables' own
// fragment maps (always current) and an index over the tombstones in the
// table files of one version.

#ifndef STORAGE_LEVELDB_DB_RANGE_DEL_VIEW_H_
#define STORAGE_LEVELDB_DB_RANGE_DEL_VIEW_H_

#include <memory>
#include <string>

#include "db/memtable.h"
#include "db/range_del.h"

namespace leveldb {

class RangeDelView {
 public:
  // The caller keeps mem and imm (may be null) alive while the view is used.
  RangeDelView(MemTable* mem, MemTable* imm,
               std::shared_ptr<const RangeDelIndex> tables)
      : mem_(mem), imm_(imm), tables_(std::move(tables)) {}

  // The largest sequence number <= snapshot among the tombstones of layers
  // below `below_layer` that cover user_key, or 0.
  SequenceNumber MaxCovering(const Slice& user_key, SequenceNumber snapshot,
                             int below_layer = kAllLayers) const {
    SequenceNumber best = 0;
    if (below_layer > kLayerMem && mem_ != nullptr &&
        mem_->NumRangeTombstones() > 0) {
      best = std::max(best, mem_->MaxCoveringRangeDel(user_key, snapshot));
    }
    if (below_layer > kLayerImm && imm_ != nullptr &&
        imm_->NumRangeTombstones() > 0) {
      best = std::max(best, imm_->MaxCoveringRangeDel(user_key, snapshot));
    }
    if (tables_ != nullptr) {
      best = std::max(best,
                      tables_->MaxCovering(user_key, snapshot, below_layer));
    }
    return best;
  }

  bool Covers(const Slice& user_key, SequenceNumber seq,
              SequenceNumber snapshot) const {
    return MaxCovering(user_key, snapshot) > seq;
  }

  bool CoveredRange(const Slice& user_key, SequenceNumber snapshot,
                    int below_layer, std::string* begin,
                    std::string* end) const {
    if (below_layer > kLayerMem && mem_ != nullptr &&
        mem_->NumRangeTombstones() > 0 &&
        mem_->CoveredRangeDel(user_key, snapshot, begin, end)) {
      return true;
    }
    if (below_layer > kLayerImm && imm_ != nullptr &&
        imm_->NumRangeTombstones() > 0 &&
        imm_->CoveredRangeDel(user_key, snapshot, begin, end)) {
      return true;
    }
    return tables_ != nullptr &&
           tables_->CoveredRange(user_key, snapshot, below_layer, begin, end);
  }

 private:
  MemTable* const mem_;
  MemTable* const imm_;
  const std::shared_ptr<const RangeDelIndex> tables_;
};

}  // namespace leveldb

#endif  // STORAGE_LEVELDB_DB_RANGE_DEL_VIEW_H_
