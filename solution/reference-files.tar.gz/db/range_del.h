// Copyright (c) 2011 The LevelDB Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file. See the AUTHORS file for names of contributors.
//
// Range tombstones and the index reads use to decide whether an entry is
// covered by one.
//
// A tombstone [begin, end)@seq hides every entry of a key k with
// begin <= k < end whose sequence number is below seq, from readers whose
// snapshot is at or above seq.

#ifndef STORAGE_LEVELDB_DB_RANGE_DEL_H_
#define STORAGE_LEVELDB_DB_RANGE_DEL_H_

#include <map>
#include <memory>
#include <string>
#include <vector>

#include "db/dbformat.h"
#include "leveldb/comparator.h"
#include "leveldb/slice.h"
#include "leveldb/status.h"

namespace leveldb {

// Layers order the places data lives by age, newest first: the memtable
// (0), the immutable memtable (1), then level-0 files newest first, then
// levels 1, 2, ...  For any key, every entry in a layer is older than every
// entry of a newer layer that covers the key (a file's range includes its
// tombstones), so a tombstone hides everything of that key in the layers
// below its own.
static const int kLayerMem = 0;
static const int kLayerImm = 1;
static const int kFirstTableLayer = 2;
static const int kAllLayers = 1 << 30;

struct RangeTombstone {
  std::string begin;
  std::string end;
  SequenceNumber seq;
  int layer;  // not stored; see above

  RangeTombstone() : seq(0), layer(0) {}
  RangeTombstone(const Slice& b, const Slice& e, SequenceNumber s, int l = 0)
      : begin(b.ToString()), end(e.ToString()), seq(s), layer(l) {}
};

// Serialized form, stored in a table's range-deletion block:
//   count: varint32, then count x (begin: varstring, end: varstring,
//   seq: varint64)
void EncodeRangeTombstones(const std::vector<RangeTombstone>& t,
                           std::string* dst);
Status DecodeRangeTombstones(const Slice& src, std::vector<RangeTombstone>* t);

// An immutable index over a set of tombstones.  The key space is cut into
// fragments at every begin and end key; each fragment keeps the sequence
// numbers of the tombstones that cover it, largest first.
class RangeDelIndex {
 public:
  explicit RangeDelIndex(const Comparator* ucmp) : ucmp_(ucmp) {}

  RangeDelIndex(const RangeDelIndex&) = delete;
  RangeDelIndex& operator=(const RangeDelIndex&) = delete;

  // Add() any number of tombstones, then Finish() once before querying.
  void Add(const Slice& begin, const Slice& end, SequenceNumber seq,
           int layer = 0);
  void Add(const RangeTombstone& t) { Add(t.begin, t.end, t.seq, t.layer); }
  void Finish();

  bool empty() const { return fragments_.empty(); }
  size_t size() const { return count_; }

  // The largest sequence number <= snapshot among the tombstones of layers
  // below `below_layer` that cover user_key, or 0 if there is none.
  SequenceNumber MaxCovering(const Slice& user_key, SequenceNumber snapshot,
                             int below_layer = kAllLayers) const;

  // Is an entry for user_key written at `seq` hidden from readers at
  // `snapshot`?
  bool Covers(const Slice& user_key, SequenceNumber seq,
              SequenceNumber snapshot) const {
    return !fragments_.empty() && MaxCovering(user_key, snapshot) > seq;
  }

  // If user_key is covered by a tombstone of a layer below `below_layer`
  // visible at `snapshot`, stores a range around it covered by the same
  // tombstones in [*begin, *end) and returns true.
  bool CoveredRange(const Slice& user_key, SequenceNumber snapshot,
                    int below_layer, std::string* begin,
                    std::string* end) const;

 private:
  struct Fragment {
    std::string begin;  // fragment covers [begin, end)
    std::string end;
    // (seq, layer) of the covering tombstones, seq descending
    std::vector<std::pair<SequenceNumber, int>> seqs;
  };

  const Fragment* Find(const Slice& user_key) const;
  static SequenceNumber Best(const Fragment& f, SequenceNumber snapshot,
                             int below_layer);

  const Comparator* const ucmp_;
  std::vector<RangeTombstone> pending_;
  std::vector<Fragment> fragments_;
  size_t count_ = 0;
};

// Fragmented tombstones kept up to date as tombstones arrive (a
// memtable's): the key space covered by tombstones is cut into disjoint
// fragments, each with the sequence numbers of the tombstones over it.
// Adding a tombstone costs O(log n + fragments it overlaps); a lookup
// O(log n).  Not thread-safe.
class RangeDelMap {
 public:
  explicit RangeDelMap(const Comparator* ucmp)
      : frags_(KeyLess{ucmp}), ucmp_(ucmp) {}

  void Add(const Slice& begin, const Slice& end, SequenceNumber seq);
  SequenceNumber MaxCovering(const Slice& user_key,
                             SequenceNumber snapshot) const;
  bool CoveredRange(const Slice& user_key, SequenceNumber snapshot,
                    std::string* begin, std::string* end) const;

 private:
  struct KeyLess {
    const Comparator* ucmp;
    bool operator()(const std::string& a, const std::string& b) const {
      return ucmp->Compare(a, b) < 0;
    }
  };
  struct Frag {
    std::string end;
    std::vector<SequenceNumber> seqs;  // descending
  };
  typedef std::map<std::string, Frag, KeyLess> Map;

  Map::const_iterator Find(const Slice& user_key) const;
  static SequenceNumber Best(const Frag& f, SequenceNumber snapshot);

  Map frags_;
  const Comparator* const ucmp_;
};

class Iterator;
class InternalKeyComparator;
class RangeDelView;

// Wraps an internal iterator over one layer so that it never stops on an
// entry hidden by a tombstone of a newer layer (below `layer`) visible at
// `snapshot`: it seeks past the covered range instead, in either direction,
// without reading what lies inside.  Takes ownership of `iter`.
Iterator* NewRangeDelSkippingIterator(Iterator* iter,
                                      const InternalKeyComparator* icmp,
                                      std::shared_ptr<const RangeDelView> view,
                                      int layer, SequenceNumber snapshot);

}  // namespace leveldb

#endif  // STORAGE_LEVELDB_DB_RANGE_DEL_H_
