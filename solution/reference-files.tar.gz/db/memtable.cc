// Copyright (c) 2011 The LevelDB Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file. See the AUTHORS file for names of contributors.

#include "db/memtable.h"
#include "db/dbformat.h"
#include "db/lookup_state.h"
#include "db/range_del.h"
#include "leveldb/comparator.h"
#include "leveldb/env.h"
#include "leveldb/iterator.h"
#include "util/coding.h"
#include "util/mutexlock.h"

namespace leveldb {

static Slice GetLengthPrefixedSlice(const char* data) {
  uint32_t len;
  const char* p = data;
  p = GetVarint32Ptr(p, p + 5, &len);  // +5: we assume "p" is not corrupted
  return Slice(p, len);
}

MemTable::MemTable(const InternalKeyComparator& comparator)
    : comparator_(comparator),
      refs_(0),
      table_(comparator_, &arena_),
      range_del_map_(comparator.user_comparator()),
      num_range_dels_(0),
      id_([] {
        static std::atomic<uint64_t> next{0};
        return ++next;
      }()) {}

MemTable::~MemTable() { assert(refs_ == 0); }

size_t MemTable::ApproximateMemoryUsage() { return arena_.MemoryUsage(); }

int MemTable::KeyComparator::operator()(const char* aptr,
                                        const char* bptr) const {
  // Internal keys are encoded as length-prefixed strings.
  Slice a = GetLengthPrefixedSlice(aptr);
  Slice b = GetLengthPrefixedSlice(bptr);
  return comparator.Compare(a, b);
}

// Encode a suitable internal key target for "target" and return it.
// Uses *scratch as scratch space, and the returned pointer will point
// into this scratch space.
static const char* EncodeKey(std::string* scratch, const Slice& target) {
  scratch->clear();
  PutVarint32(scratch, target.size());
  scratch->append(target.data(), target.size());
  return scratch->data();
}

class MemTableIterator : public Iterator {
 public:
  explicit MemTableIterator(MemTable::Table* table) : iter_(table) {}

  MemTableIterator(const MemTableIterator&) = delete;
  MemTableIterator& operator=(const MemTableIterator&) = delete;

  ~MemTableIterator() override = default;

  bool Valid() const override { return iter_.Valid(); }
  void Seek(const Slice& k) override { iter_.Seek(EncodeKey(&tmp_, k)); }
  void SeekToFirst() override { iter_.SeekToFirst(); }
  void SeekToLast() override { iter_.SeekToLast(); }
  void Next() override { iter_.Next(); }
  void Prev() override { iter_.Prev(); }
  Slice key() const override { return GetLengthPrefixedSlice(iter_.key()); }
  Slice value() const override {
    Slice key_slice = GetLengthPrefixedSlice(iter_.key());
    return GetLengthPrefixedSlice(key_slice.data() + key_slice.size());
  }

  Status status() const override { return Status::OK(); }

 private:
  MemTable::Table::Iterator iter_;
  std::string tmp_;  // For passing to EncodeKey
};

Iterator* MemTable::NewIterator() { return new MemTableIterator(&table_); }

void MemTable::Add(SequenceNumber s, ValueType type, const Slice& key,
                   const Slice& value) {
  // Format of an entry is concatenation of:
  //  key_size     : varint32 of internal_key.size()
  //  key bytes    : char[internal_key.size()]
  //  value_size   : varint32 of value.size()
  //  value bytes  : char[value.size()]
  if (type == kTypeRangeDeletion) {
    if (comparator_.comparator.user_comparator()->Compare(key, value) >= 0) {
      return;  // empty range
    }
    // Kept in insertion order, outside the arena (charged to it for the
    // memory estimate).
    arena_.Allocate(key.size() + value.size() + 16);
    MutexLock l(&range_dels_mu_);
    range_dels_.emplace_back(key, value, s);
    range_del_map_.Add(key, value, s);
    num_range_dels_.fetch_add(1, std::memory_order_release);
    return;
  }
  size_t key_size = key.size();
  size_t val_size = value.size();
  size_t internal_key_size = key_size + 8;
  const size_t encoded_len = VarintLength(internal_key_size) +
                             internal_key_size + VarintLength(val_size) +
                             val_size;
  char* buf = arena_.Allocate(encoded_len);
  char* p = EncodeVarint32(buf, internal_key_size);
  std::memcpy(p, key.data(), key_size);
  p += key_size;
  EncodeFixed64(p, (s << 8) | type);
  p += 8;
  p = EncodeVarint32(p, val_size);
  std::memcpy(p, value.data(), val_size);
  assert(p + val_size == buf + encoded_len);
  table_.Insert(buf);
}

SequenceNumber MemTable::MaxCoveringRangeDel(const Slice& user_key,
                                            SequenceNumber snapshot) {
  MutexLock l(&range_dels_mu_);
  return range_del_map_.MaxCovering(user_key, snapshot);
}

bool MemTable::CoveredRangeDel(const Slice& user_key, SequenceNumber snapshot,
                               std::string* begin, std::string* end) {
  MutexLock l(&range_dels_mu_);
  return range_del_map_.CoveredRange(user_key, snapshot, begin, end);
}

void MemTable::GetRangeTombstones(std::vector<RangeTombstone>* out,
                                  size_t from, int layer) {
  MutexLock l(&range_dels_mu_);
  for (size_t i = from; i < range_dels_.size(); i++) {
    out->push_back(range_dels_[i]);
    out->back().layer = layer;
  }
}

bool MemTable::Get(const LookupKey& key, LookupState* state) {
  Slice memkey = key.memtable_key();
  Table::Iterator iter(&table_);
  const Comparator* ucmp = comparator_.comparator.user_comparator();
  // Seek() skips every entry with a sequence number above the lookup's.
  for (iter.Seek(memkey.data()); iter.Valid(); iter.Next()) {
    // entry format is:
    //    klength  varint32
    //    userkey  char[klength]
    //    tag      uint64
    //    vlength  varint32
    //    value    char[vlength]
    const char* entry = iter.key();
    uint32_t key_length;
    const char* key_ptr = GetVarint32Ptr(entry, entry + 5, &key_length);
    if (ucmp->Compare(Slice(key_ptr, key_length - 8), key.user_key()) != 0) {
      break;
    }
    const uint64_t tag = DecodeFixed64(key_ptr + key_length - 8);
    Slice v = GetLengthPrefixedSlice(key_ptr + key_length);
    if (state->Add(static_cast<ValueType>(tag & 0xff), tag >> 8, v)) {
      return true;
    }
  }
  return false;
}

}  // namespace leveldb
