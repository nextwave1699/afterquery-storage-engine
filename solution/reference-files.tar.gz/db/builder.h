// Copyright (c) 2011 The LevelDB Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file. See the AUTHORS file for names of contributors.

#ifndef STORAGE_LEVELDB_DB_BUILDER_H_
#define STORAGE_LEVELDB_DB_BUILDER_H_

#include <vector>

#include "db/range_del.h"
#include "leveldb/status.h"

namespace leveldb {

struct Options;
struct FileMetaData;

class Env;
class InternalKey;
class InternalKeyComparator;
class Iterator;
class TableCache;
class VersionEdit;

// Build a Table file from the contents of *iter.  The generated file
// will be named according to meta->number.  On success, the rest of
// *meta will be filled with metadata about the generated table.
// `tombstones` go to the table's range-deletion block.
// If no data is present in *iter and there are no tombstones,
// meta->file_size will be set to zero, and no Table file will be produced.
Status BuildTable(const std::string& dbname, Env* env, const Options& options,
                  TableCache* table_cache, Iterator* iter, FileMetaData* meta,
                  const std::vector<RangeTombstone>& tombstones =
                      std::vector<RangeTombstone>());

// Widens [*smallest, *largest] to cover `tombstones` (see FileMetaData).
// `have_keys` says whether they already hold the table's point keys.
void AddTombstoneBounds(const InternalKeyComparator& icmp,
                        const std::vector<RangeTombstone>& tombstones,
                        bool have_keys, InternalKey* smallest,
                        InternalKey* largest);

}  // namespace leveldb

#endif  // STORAGE_LEVELDB_DB_BUILDER_H_
