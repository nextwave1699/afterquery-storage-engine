// Copyright (c) 2011 The LevelDB Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file. See the AUTHORS file for names of contributors.

#ifndef STORAGE_LEVELDB_DB_DB_IMPL_H_
#define STORAGE_LEVELDB_DB_DB_IMPL_H_

#include <atomic>
#include <deque>
#include <memory>
#include <set>
#include <string>

#include <map>

#include "db/column_family.h"
#include "db/dbformat.h"
#include "db/range_del_view.h"
#include "db/log_writer.h"
#include "db/snapshot.h"
#include "db/version_edit.h"
#include "leveldb/db.h"
#include "leveldb/env.h"
#include "port/port.h"
#include "port/thread_annotations.h"

namespace leveldb {

class MemTable;
class TableCache;
class Version;
class VersionEdit;
class VersionSet;

class DBImpl : public DB {
 public:
  DBImpl(const Options& options, const std::string& dbname);

  DBImpl(const DBImpl&) = delete;
  DBImpl& operator=(const DBImpl&) = delete;

  ~DBImpl() override;

  // Implementations of the DB interface
  Status Put(const WriteOptions&, const Slice& key,
             const Slice& value) override;
  Status Put(const WriteOptions&, ColumnFamilyHandle*, const Slice& key,
             const Slice& value) override;
  Status Delete(const WriteOptions&, const Slice& key) override;
  Status Delete(const WriteOptions&, ColumnFamilyHandle*,
                const Slice& key) override;
  Status DeleteRange(const WriteOptions&, const Slice& begin,
                     const Slice& end) override;
  Status DeleteRange(const WriteOptions&, ColumnFamilyHandle*,
                     const Slice& begin, const Slice& end) override;
  Status Merge(const WriteOptions&, const Slice& key,
               const Slice& value) override;
  Status Merge(const WriteOptions&, ColumnFamilyHandle*, const Slice& key,
               const Slice& value) override;
  Status Write(const WriteOptions& options, WriteBatch* updates) override;
  Status Get(const ReadOptions& options, const Slice& key,
             std::string* value) override;
  Status Get(const ReadOptions& options, ColumnFamilyHandle*, const Slice& key,
             std::string* value) override;
  Iterator* NewIterator(const ReadOptions&) override;
  Iterator* NewIterator(const ReadOptions&, ColumnFamilyHandle*) override;
  const Snapshot* GetSnapshot() override;
  void ReleaseSnapshot(const Snapshot* snapshot) override;
  bool GetProperty(const Slice& property, std::string* value) override;
  bool GetProperty(ColumnFamilyHandle*, const Slice& property,
                   std::string* value) override;
  void GetApproximateSizes(const Range* range, int n, uint64_t* sizes) override;
  void CompactRange(const Slice* begin, const Slice* end) override;
  void CompactRange(ColumnFamilyHandle*, const Slice* begin,
                    const Slice* end) override;

  Status CreateColumnFamily(const Options& options, const std::string& name,
                            ColumnFamilyHandle** handle) override;
  Status DropColumnFamily(ColumnFamilyHandle* handle) override;
  Status DestroyColumnFamilyHandle(ColumnFamilyHandle* handle) override;
  ColumnFamilyHandle* DefaultColumnFamily() const override;

  // Extra methods (for testing) that are not in the public DB interface

  // Compact any files in the named level that overlap [*begin,*end]
  void TEST_CompactRange(int level, const Slice* begin, const Slice* end);

  // Force current memtable contents to be compacted.
  Status TEST_CompactMemTable();

  // Return an internal iterator over the current state of the database.
  // The keys of this iterator are internal keys (see format.h).
  // The returned iterator should be deleted when no longer needed.
  Iterator* TEST_NewInternalIterator();

  // Return the maximum overlapping data (in bytes) at next level for any
  // file at a level >= 1.
  int64_t TEST_MaxNextLevelOverlappingBytes();

  // Record a sample of bytes read at the specified internal key.
  // Samples are taken approximately once every config::kReadBytesPeriod
  // bytes.
  void RecordReadSample(Slice key);

 private:
  friend class DB;
  friend Status DB::Open(const Options&, const std::string&,
                         const std::vector<ColumnFamilyDescriptor>&,
                         std::vector<ColumnFamilyHandle*>*, DB**);
  struct CompactionState;
  struct Writer;

  // Also returns, in *range_dels, a view of every range tombstone the
  // iterator may meet (nullptr if there is none); the iterators of older
  // layers then skip what newer layers' tombstones hide.
  Iterator* NewInternalIterator(
      const ReadOptions&, ColumnFamily* cf, SequenceNumber* latest_snapshot,
      uint32_t* seed, std::shared_ptr<const RangeDelView>* range_dels = nullptr);

  // A view of the range tombstones of mem, imm and v, nullptr if they hold
  // none.  The memtables answer from their own fragment maps; the tables'
  // tombstones are indexed once per version.
  std::shared_ptr<const RangeDelView> RangeDelsLocked(ColumnFamily* cf,
                                                      MemTable* mem,
                                                      MemTable* imm,
                                                      Version* v, Status* s)
      EXCLUSIVE_LOCKS_REQUIRED(mutex_);

  // Creates the on-disk state of one family (its directory, CURRENT and
  // MANIFEST); the default family's is the database's own.
  Status NewDB(const std::string& dir);

  // Opens the family's version set, and its memtable if the log is replayed
  // later.  Called for every family at open.
  Status OpenColumnFamily(ColumnFamily* cf, bool* save_manifest,
                          VersionEdit* edit) EXCLUSIVE_LOCKS_REQUIRED(mutex_);

  // Recover the descriptors of every family from persistent storage and
  // replay the shared log.  `families` names the families the caller
  // expects (empty: whatever the database has, which must be the default
  // one alone).
  Status Recover(const std::vector<ColumnFamilyDescriptor>& families,
                 bool create_missing_families, bool* save_manifest)
      EXCLUSIVE_LOCKS_REQUIRED(mutex_);

  void MaybeIgnoreError(Status* s) const;

  // Delete any unneeded files and stale in-memory entries, over every
  // family and the shared logs.
  void RemoveObsoleteFiles() EXCLUSIVE_LOCKS_REQUIRED(mutex_);

  // Compact the in-memory write buffer of `cf` to disk.  Errors are
  // recorded in bg_error_.
  void CompactMemTable(ColumnFamily* cf) EXCLUSIVE_LOCKS_REQUIRED(mutex_);

  Status RecoverLogFile(uint64_t log_number, bool last_log,
                        SequenceNumber* max_sequence)
      EXCLUSIVE_LOCKS_REQUIRED(mutex_);

  Status WriteLevel0Table(ColumnFamily* cf, MemTable* mem, VersionEdit* edit,
                          Version* base) EXCLUSIVE_LOCKS_REQUIRED(mutex_);

  // Makes room in every family of `families` (ids), switching memtables and
  // the shared log as needed.
  Status MakeRoomForWrite(const std::set<uint32_t>& families, bool force)
      EXCLUSIVE_LOCKS_REQUIRED(mutex_);

  // Starts a new log file and moves every family whose memtable is being
  // flushed onto it; also flushes families that hold old logs back.
  Status SwitchLog() EXCLUSIVE_LOCKS_REQUIRED(mutex_);

  // The oldest log any family still needs.
  uint64_t OldestLiveLog() const EXCLUSIVE_LOCKS_REQUIRED(mutex_);

  Status CreateColumnFamilyLocked(const Options& options,
                                  const std::string& name,
                                  ColumnFamilyHandle** handle)
      EXCLUSIVE_LOCKS_REQUIRED(mutex_);
  ColumnFamily* FamilyOf(ColumnFamilyHandle* handle) const;
  Status CheckFamily(ColumnFamilyHandle* handle, ColumnFamily** cf) const;
  WriteBatch* BuildBatchGroup(Writer** last_writer)
      EXCLUSIVE_LOCKS_REQUIRED(mutex_);

  void RecordBackgroundError(const Status& s);

  void MaybeScheduleCompaction() EXCLUSIVE_LOCKS_REQUIRED(mutex_);
  bool NeedsBackgroundWork() const EXCLUSIVE_LOCKS_REQUIRED(mutex_);
  static void BGWork(void* db);
  void BackgroundCall();
  void BackgroundCompaction() EXCLUSIVE_LOCKS_REQUIRED(mutex_);
  void CleanupCompaction(CompactionState* compact)
      EXCLUSIVE_LOCKS_REQUIRED(mutex_);
  Status DoCompactionWork(CompactionState* compact)
      EXCLUSIVE_LOCKS_REQUIRED(mutex_);

  Status OpenCompactionOutputFile(CompactionState* compact);
  // Finishes the current output.  `upper_cut` is the first user key of the
  // next output (nullptr for the last one); the file gets the parts of the
  // compaction's range tombstones below it.
  Status FinishCompactionOutputFile(CompactionState* compact, Iterator* input,
                                    const Slice* upper_cut);
  Status InstallCompactionResults(CompactionState* compact)
      EXCLUSIVE_LOCKS_REQUIRED(mutex_);

  const Comparator* user_comparator() const { return user_comparator_; }

  // Constant after construction
  Env* const env_;
  const Comparator* const user_comparator_;
  const Options db_options_;  // shared options (env, info_log, caches, ...)
  const bool owns_info_log_;
  const bool owns_cache_;
  const std::string dbname_;

  // Lock over the persistent DB state.  Non-null iff successfully acquired.
  FileLock* db_lock_;

  // State below is protected by mutex_
  port::Mutex mutex_;
  std::atomic<bool> shutting_down_;
  port::CondVar background_work_finished_signal_ GUARDED_BY(mutex_);

  // The column families, by id, and their handles.  cfs_ owns them; a
  // family stays alive while a handle or the database holds a reference.
  std::map<uint32_t, ColumnFamily*> cfs_ GUARDED_BY(mutex_);
  ColumnFamily* default_cf_ = nullptr;
  ColumnFamilyHandleImpl* default_handle_ = nullptr;
  uint32_t next_family_id_ GUARDED_BY(mutex_) = 1;

  WritableFile* logfile_;
  uint64_t logfile_number_ GUARDED_BY(mutex_);
  log::Writer* log_;
  uint32_t seed_ GUARDED_BY(mutex_);  // For sampling.
  // The database's sequence numbers, shared by every family.
  SequenceNumber last_sequence_ GUARDED_BY(mutex_) = 0;

  // Queue of writers.
  // Files written while replaying the log at open, per family: they are
  // applied once, at the end, with the log number of the memtable that
  // will take the writes.  Applying them earlier would claim a log is
  // flushed while its later records are still being replayed.
  std::map<uint32_t, VersionEdit> recovery_edits_ GUARDED_BY(mutex_);

  std::deque<Writer*> writers_ GUARDED_BY(mutex_);
  WriteBatch* tmp_batch_ GUARDED_BY(mutex_);

  SnapshotList snapshots_ GUARDED_BY(mutex_);

  // Set while any family has a memtable waiting to be flushed, so a
  // running compaction can notice without taking the lock.
  std::atomic<bool> pending_flush_{false};

  // Has a background compaction been scheduled or is running?
  bool background_compaction_scheduled_ GUARDED_BY(mutex_);

  // Have we encountered a background error in paranoid mode?
  Status bg_error_ GUARDED_BY(mutex_);
};

// Sanitize db options.  The caller should delete result.info_log if
// it is not equal to src.info_log.
Options SanitizeOptions(const std::string& db,
                        const InternalKeyComparator* icmp,
                        const InternalFilterPolicy* ipolicy,
                        const Options& src);

}  // namespace leveldb

#endif  // STORAGE_LEVELDB_DB_DB_IMPL_H_
