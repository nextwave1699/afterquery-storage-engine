// Copyright (c) 2011 The LevelDB Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file. See the AUTHORS file for names of contributors.

#ifndef STORAGE_LEVELDB_DB_MEMTABLE_H_
#define STORAGE_LEVELDB_DB_MEMTABLE_H_

#include <string>
#include <vector>

#include "db/dbformat.h"
#include "db/skiplist.h"
#include "leveldb/db.h"
#include "db/range_del.h"
#include "port/port.h"
#include "port/thread_annotations.h"
#include "util/arena.h"

#include <atomic>

namespace leveldb {

class InternalKeyComparator;
class LookupState;
class MemTableIterator;
struct RangeTombstone;

class MemTable {
 public:
  // MemTables are reference counted.  The initial reference count
  // is zero and the caller must call Ref() at least once.
  explicit MemTable(const InternalKeyComparator& comparator);

  MemTable(const MemTable&) = delete;
  MemTable& operator=(const MemTable&) = delete;

  // Increase reference count.
  void Ref() { ++refs_; }

  // Drop reference count.  Delete if no more references exist.
  void Unref() {
    --refs_;
    assert(refs_ >= 0);
    if (refs_ <= 0) {
      delete this;
    }
  }

  // Returns an estimate of the number of bytes of data in use by this
  // data structure. It is safe to call when MemTable is being modified.
  size_t ApproximateMemoryUsage();

  // Return an iterator that yields the contents of the memtable.
  //
  // The caller must ensure that the underlying MemTable remains live
  // while the returned iterator is live.  The keys returned by this
  // iterator are internal keys encoded by AppendInternalKey in the
  // db/format.{h,cc} module.
  Iterator* NewIterator();

  // Add an entry into memtable that maps key to value at the
  // specified sequence number and with the specified type.
  // Typically value will be empty if type==kTypeDeletion.  For
  // kTypeRangeDeletion, key is the begin and value the end of the range;
  // it goes to the range-deletion table (empty ranges are dropped).
  void Add(SequenceNumber seq, ValueType type, const Slice& key,
           const Slice& value);

  // Feed the entries of key.user_key() visible at key's sequence number,
  // newest first, to *state.  Returns true once the lookup is settled.
  bool Get(const LookupKey& key, LookupState* state);

  // Unique for the life of the process.
  uint64_t id() const { return id_; }

  // Number of range tombstones added so far.  Safe to call while the
  // memtable is being modified.
  size_t NumRangeTombstones() const {
    return num_range_dels_.load(std::memory_order_acquire);
  }

  // Appends the range tombstones, in the order they were added, from the
  // `from`-th on, to *out (with layer `layer`).
  void GetRangeTombstones(std::vector<RangeTombstone>* out, size_t from = 0,
                          int layer = 0);

  // Range tombstone lookups (see RangeDelMap).
  SequenceNumber MaxCoveringRangeDel(const Slice& user_key,
                                     SequenceNumber snapshot);
  bool CoveredRangeDel(const Slice& user_key, SequenceNumber snapshot,
                       std::string* begin, std::string* end);

 private:
  friend class MemTableIterator;
  friend class MemTableBackwardIterator;

  struct KeyComparator {
    const InternalKeyComparator comparator;
    explicit KeyComparator(const InternalKeyComparator& c) : comparator(c) {}
    int operator()(const char* a, const char* b) const;
  };

  typedef SkipList<const char*, KeyComparator> Table;

  ~MemTable();  // Private since only Unref() should be used to delete it

  KeyComparator comparator_;
  int refs_;
  Arena arena_;
  Table table_;
  port::Mutex range_dels_mu_;
  std::vector<RangeTombstone> range_dels_ GUARDED_BY(range_dels_mu_);
  RangeDelMap range_del_map_ GUARDED_BY(range_dels_mu_);
  std::atomic<size_t> num_range_dels_;
  const uint64_t id_;
};

}  // namespace leveldb

#endif  // STORAGE_LEVELDB_DB_MEMTABLE_H_
