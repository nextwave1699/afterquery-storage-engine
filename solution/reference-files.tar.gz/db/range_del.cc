// Copyright (c) 2011 The LevelDB Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file. See the AUTHORS file for names of contributors.

#include "db/range_del.h"

#include <algorithm>

#include "db/range_del_view.h"
#include "leveldb/iterator.h"
#include "util/coding.h"

namespace leveldb {

void EncodeRangeTombstones(const std::vector<RangeTombstone>& t,
                           std::string* dst) {
  PutVarint32(dst, static_cast<uint32_t>(t.size()));
  for (const RangeTombstone& r : t) {
    PutLengthPrefixedSlice(dst, r.begin);
    PutLengthPrefixedSlice(dst, r.end);
    PutVarint64(dst, r.seq);
  }
}

Status DecodeRangeTombstones(const Slice& src, std::vector<RangeTombstone>* t) {
  Slice in = src;
  uint32_t n;
  if (!GetVarint32(&in, &n)) {
    return Status::Corruption("bad range-deletion block");
  }
  t->reserve(t->size() + n);
  for (uint32_t i = 0; i < n; i++) {
    Slice b, e;
    uint64_t seq;
    if (!GetLengthPrefixedSlice(&in, &b) || !GetLengthPrefixedSlice(&in, &e) ||
        !GetVarint64(&in, &seq)) {
      return Status::Corruption("bad range-deletion block");
    }
    t->emplace_back(b, e, seq);
  }
  return Status::OK();
}

void RangeDelIndex::Add(const Slice& begin, const Slice& end,
                        SequenceNumber seq, int layer) {
  if (ucmp_->Compare(begin, end) >= 0) return;
  pending_.emplace_back(begin, end, seq, layer);
  count_++;
}

void RangeDelIndex::Finish() {
  fragments_.clear();
  if (pending_.empty()) return;
  // Every begin and end is a cut point.
  std::vector<std::string> cuts;
  cuts.reserve(pending_.size() * 2);
  for (const RangeTombstone& t : pending_) {
    cuts.push_back(t.begin);
    cuts.push_back(t.end);
  }
  const Comparator* ucmp = ucmp_;
  auto less = [ucmp](const std::string& a, const std::string& b) {
    return ucmp->Compare(a, b) < 0;
  };
  std::sort(cuts.begin(), cuts.end(), less);
  cuts.erase(std::unique(cuts.begin(), cuts.end(),
                         [ucmp](const std::string& a, const std::string& b) {
                           return ucmp->Compare(a, b) == 0;
                         }),
             cuts.end());
  // Sweep: tombstones sorted by begin enter, and leave at their end.
  std::sort(pending_.begin(), pending_.end(),
            [ucmp](const RangeTombstone& a, const RangeTombstone& b) {
              return ucmp->Compare(a.begin, b.begin) < 0;
            });
  std::vector<const RangeTombstone*> active;
  size_t next = 0;
  for (size_t i = 0; i + 1 < cuts.size(); i++) {
    const std::string& lo = cuts[i];
    while (next < pending_.size() &&
           ucmp->Compare(pending_[next].begin, lo) <= 0) {
      active.push_back(&pending_[next]);
      next++;
    }
    active.erase(std::remove_if(active.begin(), active.end(),
                                [&](const RangeTombstone* t) {
                                  return ucmp->Compare(t->end, lo) <= 0;
                                }),
                 active.end());
    if (active.empty()) continue;
    Fragment f;
    f.begin = lo;
    f.end = cuts[i + 1];
    f.seqs.reserve(active.size());
    for (const RangeTombstone* t : active) f.seqs.emplace_back(t->seq, t->layer);
    std::sort(f.seqs.begin(), f.seqs.end(),
              [](const std::pair<SequenceNumber, int>& a,
                 const std::pair<SequenceNumber, int>& b) {
                return a.first > b.first;
              });
    fragments_.push_back(std::move(f));
  }
  pending_.clear();
  pending_.shrink_to_fit();
}

const RangeDelIndex::Fragment* RangeDelIndex::Find(
    const Slice& user_key) const {
  // Last fragment whose begin <= user_key.
  size_t lo = 0, hi = fragments_.size();
  while (lo < hi) {
    size_t mid = (lo + hi) / 2;
    if (ucmp_->Compare(fragments_[mid].begin, user_key) <= 0) {
      lo = mid + 1;
    } else {
      hi = mid;
    }
  }
  if (lo == 0) return nullptr;
  const Fragment& f = fragments_[lo - 1];
  if (ucmp_->Compare(user_key, f.end) >= 0) return nullptr;
  return &f;
}

SequenceNumber RangeDelIndex::Best(const Fragment& f, SequenceNumber snapshot,
                                   int below_layer) {
  for (const auto& p : f.seqs) {
    if (p.first <= snapshot && p.second < below_layer) return p.first;
  }
  return 0;
}

SequenceNumber RangeDelIndex::MaxCovering(const Slice& user_key,
                                          SequenceNumber snapshot,
                                          int below_layer) const {
  const Fragment* f = Find(user_key);
  return f == nullptr ? 0 : Best(*f, snapshot, below_layer);
}

bool RangeDelIndex::CoveredRange(const Slice& user_key, SequenceNumber snapshot,
                                 int below_layer, std::string* begin,
                                 std::string* end) const {
  const Fragment* f = Find(user_key);
  if (f == nullptr || Best(*f, snapshot, below_layer) == 0) return false;
  *begin = f->begin;
  *end = f->end;
  return true;
}

void RangeDelMap::Add(const Slice& begin, const Slice& end,
                      SequenceNumber seq) {
  if (ucmp_->Compare(begin, end) >= 0) return;
  std::string pos = begin.ToString();
  const std::string stop = end.ToString();
  // Split the fragment that straddles `begin`.
  auto it = frags_.upper_bound(pos);
  if (it != frags_.begin()) {
    auto prev = std::prev(it);
    if (ucmp_->Compare(prev->first, pos) < 0 &&
        ucmp_->Compare(pos, prev->second.end) < 0) {
      Frag right = prev->second;
      prev->second.end = pos;
      it = frags_.emplace_hint(it, pos, std::move(right));
    }
  }
  it = frags_.lower_bound(pos);
  while (ucmp_->Compare(pos, stop) < 0) {
    if (it == frags_.end() || ucmp_->Compare(pos, it->first) < 0) {
      // a gap up to the next fragment (or the end of the tombstone)
      std::string gap_end = stop;
      if (it != frags_.end() && ucmp_->Compare(it->first, stop) < 0) {
        gap_end = it->first;
      }
      Frag f;
      f.end = gap_end;
      f.seqs.push_back(seq);
      frags_.emplace_hint(it, pos, std::move(f));
      pos = gap_end;
      continue;
    }
    // `it` starts at pos
    if (ucmp_->Compare(stop, it->second.end) < 0) {
      Frag right = it->second;
      it->second.end = stop;
      frags_.emplace_hint(std::next(it), stop, std::move(right));
    }
    std::vector<SequenceNumber>& v = it->second.seqs;
    v.insert(std::upper_bound(v.begin(), v.end(), seq,
                              std::greater<SequenceNumber>()),
             seq);
    pos = it->second.end;
    ++it;
  }
}

RangeDelMap::Map::const_iterator RangeDelMap::Find(
    const Slice& user_key) const {
  auto it = frags_.upper_bound(user_key.ToString());
  if (it == frags_.begin()) return frags_.end();
  --it;
  if (ucmp_->Compare(user_key, it->second.end) >= 0) return frags_.end();
  return it;
}

SequenceNumber RangeDelMap::Best(const Frag& f, SequenceNumber snapshot) {
  for (SequenceNumber s : f.seqs) {
    if (s <= snapshot) return s;
  }
  return 0;
}

SequenceNumber RangeDelMap::MaxCovering(const Slice& user_key,
                                        SequenceNumber snapshot) const {
  auto it = Find(user_key);
  return it == frags_.end() ? 0 : Best(it->second, snapshot);
}

bool RangeDelMap::CoveredRange(const Slice& user_key, SequenceNumber snapshot,
                               std::string* begin, std::string* end) const {
  auto it = Find(user_key);
  if (it == frags_.end() || Best(it->second, snapshot) == 0) return false;
  *begin = it->first;
  *end = it->second.end;
  return true;
}

namespace {

class RangeDelSkippingIterator : public Iterator {
 public:
  RangeDelSkippingIterator(Iterator* iter, const InternalKeyComparator* icmp,
                           std::shared_ptr<const RangeDelView> view, int layer,
                           SequenceNumber snapshot)
      : iter_(iter),
        icmp_(icmp),
        view_(std::move(view)),
        layer_(layer),
        snapshot_(snapshot) {}

  ~RangeDelSkippingIterator() override { delete iter_; }

  bool Valid() const override { return iter_->Valid(); }
  Slice key() const override { return iter_->key(); }
  Slice value() const override { return iter_->value(); }
  Status status() const override { return iter_->status(); }

  void Seek(const Slice& target) override {
    iter_->Seek(target);
    SkipForward();
  }
  void SeekToFirst() override {
    iter_->SeekToFirst();
    SkipForward();
  }
  void SeekToLast() override {
    iter_->SeekToLast();
    SkipBackward();
  }
  void Next() override {
    iter_->Next();
    SkipForward();
  }
  void Prev() override {
    iter_->Prev();
    SkipBackward();
  }

 private:
  bool Covered(std::string* begin, std::string* end) {
    ParsedInternalKey ikey;
    if (!ParseInternalKey(iter_->key(), &ikey)) return false;
    return view_->CoveredRange(ikey.user_key, snapshot_, layer_, begin, end);
  }

  void SkipForward() {
    std::string b, e;
    while (iter_->Valid() && Covered(&b, &e)) {
      std::string target;
      AppendInternalKey(&target,
                        ParsedInternalKey(e, kMaxSequenceNumber, kValueTypeForSeek));
      iter_->Seek(target);
    }
  }

  void SkipBackward() {
    std::string b, e;
    while (iter_->Valid() && Covered(&b, &e)) {
      std::string target;
      AppendInternalKey(&target,
                        ParsedInternalKey(b, kMaxSequenceNumber, kValueTypeForSeek));
      iter_->Seek(target);
      if (iter_->Valid()) {
        iter_->Prev();
      } else {
        iter_->SeekToLast();
      }
    }
  }

  Iterator* const iter_;
  const InternalKeyComparator* const icmp_;
  const std::shared_ptr<const RangeDelView> view_;
  const int layer_;
  const SequenceNumber snapshot_;
};

}  // namespace

Iterator* NewRangeDelSkippingIterator(Iterator* iter,
                                      const InternalKeyComparator* icmp,
                                      std::shared_ptr<const RangeDelView> view,
                                      int layer, SequenceNumber snapshot) {
  return new RangeDelSkippingIterator(iter, icmp, std::move(view), layer,
                                      snapshot);
}

}  // namespace leveldb
