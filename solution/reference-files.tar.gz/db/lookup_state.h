// Copyright (c) 2011 The LevelDB Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file. See the AUTHORS file for names of contributors.
//
// The state of a point lookup as it walks down the memtables and levels:
// entries of the key are fed newest first until one of them settles the
// value (a put, a deletion, or an entry hidden by a range tombstone), with
// merge operands collected on the way.

#ifndef STORAGE_LEVELDB_DB_LOOKUP_STATE_H_
#define STORAGE_LEVELDB_DB_LOOKUP_STATE_H_

#include <string>
#include <vector>

#include "db/dbformat.h"
#include "db/range_del_view.h"
#include "leveldb/merge_operator.h"
#include "leveldb/status.h"

namespace leveldb {

class LookupState {
 public:
  // `rd` may be null (no range tombstones anywhere).
  LookupState(const Slice& user_key, SequenceNumber snapshot,
              const MergeOperator* merge_op, const RangeDelView* rd,
              std::string* value)
      : user_key_(user_key),
        snapshot_(snapshot),
        merge_op_(merge_op),
        rd_(rd),
        value_(value) {}

  const Slice& user_key() const { return user_key_; }
  SequenceNumber snapshot() const { return snapshot_; }

  // Feed the next (older) entry of the key; its sequence number must be at
  // most the snapshot.  Returns true once the lookup is settled.
  bool Add(ValueType type, SequenceNumber seq, const Slice& value) {
    if (done_) return true;
    if (type != kTypeDeletion && rd_ != nullptr &&
        rd_->Covers(user_key_, seq, snapshot_)) {
      type = kTypeDeletion;
    }
    switch (type) {
      case kTypeValue:
        Settle(&value);
        return true;
      case kTypeDeletion:
        Settle(nullptr);
        return true;
      case kTypeMerge:
        operands_.push_back(value.ToString());
        return false;
      default:
        status_ = Status::Corruption("unexpected entry type in lookup");
        done_ = true;
        return true;
    }
  }

  bool done() const { return done_; }

  // Everything older than what was fed so far is hidden (by a tombstone of
  // a newer layer): settle as if a deletion came next.
  void SettleDeleted() {
    if (!done_) Settle(nullptr);
  }
  bool has_operands() const { return !operands_.empty(); }

  // Called once nothing older is left: settles pending operands on an
  // absent value.  OK (value stored), NotFound, or an error.
  Status Finish() {
    if (!done_) Settle(nullptr);
    return status_;
  }

 private:
  void Settle(const Slice* base) {
    done_ = true;
    if (operands_.empty()) {
      if (base == nullptr) {
        status_ = Status::NotFound(Slice());
      } else {
        value_->assign(base->data(), base->size());
        status_ = Status::OK();
      }
      return;
    }
    if (merge_op_ == nullptr) {
      status_ = Status::InvalidArgument("merge operand but no merge_operator");
      return;
    }
    std::vector<std::string> ops(operands_.rbegin(), operands_.rend());
    if (merge_op_->FullMerge(user_key_, base, ops, value_)) {
      status_ = Status::OK();
    } else {
      status_ = Status::Corruption("merge operator failed");
    }
  }

  Slice user_key_;
  SequenceNumber snapshot_;
  const MergeOperator* merge_op_;
  const RangeDelView* rd_;
  std::string* value_;
  std::vector<std::string> operands_;  // newest first
  bool done_ = false;
  Status status_;
};

}  // namespace leveldb

#endif  // STORAGE_LEVELDB_DB_LOOKUP_STATE_H_
