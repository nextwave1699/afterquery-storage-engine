// Copyright (c) 2011 The LevelDB Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file. See the AUTHORS file for names of contributors.

#include "db/builder.h"

#include "db/dbformat.h"
#include "db/filename.h"
#include "db/table_cache.h"
#include "db/version_edit.h"
#include "leveldb/db.h"
#include "leveldb/env.h"
#include "leveldb/iterator.h"

namespace leveldb {

void AddTombstoneBounds(const InternalKeyComparator& icmp,
                        const std::vector<RangeTombstone>& tombstones,
                        bool have_keys, InternalKey* smallest,
                        InternalKey* largest) {
  for (const RangeTombstone& t : tombstones) {
    InternalKey lo(t.begin, t.seq, kTypeRangeDeletion);
    InternalKey hi(t.end, kMaxSequenceNumber, kTypeRangeDeletion);
    if (!have_keys || icmp.Compare(lo, *smallest) < 0) {
      *smallest = lo;
    }
    if (!have_keys || icmp.Compare(hi, *largest) > 0) {
      *largest = hi;
    }
    have_keys = true;
  }
}

Status BuildTable(const std::string& dbname, Env* env, const Options& options,
                  TableCache* table_cache, Iterator* iter, FileMetaData* meta,
                  const std::vector<RangeTombstone>& tombstones) {
  Status s;
  meta->file_size = 0;
  meta->has_range_dels = false;
  iter->SeekToFirst();

  std::string fname = TableFileName(dbname, meta->number);
  if (iter->Valid() || !tombstones.empty()) {
    WritableFile* file;
    s = env->NewWritableFile(fname, &file);
    if (!s.ok()) {
      return s;
    }

    TableBuilder* builder = new TableBuilder(options, file);
    bool have_keys = iter->Valid();
    if (have_keys) meta->smallest.DecodeFrom(iter->key());
    Slice key;
    for (; iter->Valid(); iter->Next()) {
      key = iter->key();
      builder->Add(key, iter->value());
    }
    if (!key.empty()) {
      meta->largest.DecodeFrom(key);
    }
    if (!tombstones.empty()) {
      std::string block;
      EncodeRangeTombstones(tombstones, &block);
      builder->SetRangeDeletionBlock(block);
      const InternalKeyComparator* icmp =
          static_cast<const InternalKeyComparator*>(options.comparator);
      AddTombstoneBounds(*icmp, tombstones, have_keys, &meta->smallest,
                         &meta->largest);
      meta->has_range_dels = true;
    }

    // Finish and check for builder errors
    s = builder->Finish();
    if (s.ok()) {
      meta->file_size = builder->FileSize();
      assert(meta->file_size > 0);
    }
    delete builder;

    // Finish and check for file errors
    if (s.ok()) {
      s = file->Sync();
    }
    if (s.ok()) {
      s = file->Close();
    }
    delete file;
    file = nullptr;

    if (s.ok()) {
      // Verify that the table is usable
      Iterator* it = table_cache->NewIterator(ReadOptions(), meta->number,
                                              meta->file_size);
      s = it->status();
      delete it;
    }
  }

  // Check for input iterator errors
  if (!iter->status().ok()) {
    s = iter->status();
  }

  if (s.ok() && meta->file_size > 0) {
    // Keep it
  } else {
    env->RemoveFile(fname);
  }
  return s;
}

}  // namespace leveldb
