// Copyright (c) 2011 The LevelDB Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file. See the AUTHORS file for names of contributors.
//
// One column family: an independent key space with its own options,
// memtable, levels and manifest, sharing the database's write-ahead log,
// sequence numbers, snapshots and background thread.
//
// The default family (id 0) lives in the database directory itself, so a
// database that only uses it is exactly what the engine wrote before column
// families existed.  Every other family lives in `<dbname>/cf-<id>`, with
// its own CURRENT, MANIFEST and tables.  The FAMILIES file at the top names
// them; an engine that does not know about it ignores it, and so does the
// file cleanup of older engines (the name does not parse as one of theirs).

#ifndef STORAGE_LEVELDB_DB_COLUMN_FAMILY_H_
#define STORAGE_LEVELDB_DB_COLUMN_FAMILY_H_

#include <atomic>
#include <memory>
#include <set>
#include <string>
#include <vector>

#include "db/dbformat.h"
#include "db/range_del_view.h"
#include "leveldb/db.h"
#include "leveldb/env.h"
#include "leveldb/options.h"

namespace leveldb {

class MemTable;
class TableCache;
class Version;
class VersionSet;

// Per level compaction stats.  stats[level] is for compactions that
// produced data for that level.
struct CompactionStats {
  CompactionStats() : micros(0), bytes_read(0), bytes_written(0) {}

  void Add(const CompactionStats& c) {
    this->micros += c.micros;
    this->bytes_read += c.bytes_read;
    this->bytes_written += c.bytes_written;
  }

  int64_t micros;
  int64_t bytes_read;
  int64_t bytes_written;
};

// Information for a manual compaction
struct ManualCompaction {
  int level;
  bool done;
  const InternalKey* begin;  // null means beginning of key range
  const InternalKey* end;    // null means end of key range
  InternalKey tmp_storage;   // Used to keep track of compaction progress
};

// The range tombstones of one version's tables, cached until it changes.
struct RangeDelCache {
  uint64_t version_id = 0;
  bool version_has_range_dels = false;
  std::shared_ptr<const RangeDelIndex> index;
};

struct ColumnFamily {
  ColumnFamily(uint32_t id_, std::string name_, std::string dir_,
               const Options& src, const Comparator* user_cmp)
      : id(id_),
        name(std::move(name_)),
        dir(std::move(dir_)),
        icmp(user_cmp),
        ipolicy(src.filter_policy),
        options(src) {}

  const uint32_t id;
  const std::string name;
  const std::string dir;
  const InternalKeyComparator icmp;
  const InternalFilterPolicy ipolicy;
  Options options;  // options.comparator == &icmp

  TableCache* table_cache = nullptr;
  VersionSet* versions = nullptr;

  MemTable* mem = nullptr;
  MemTable* imm = nullptr;                // memtable being flushed
  std::atomic<bool> has_imm{false};       // so the bg thread can see imm
  // The log the current memtable's writes go to; on a flush it becomes the
  // family's log number, and logs below that are no longer needed for it.
  uint64_t mem_log_number = 0;
  uint64_t imm_log_number = 0;  // the same for the memtable being flushed

  bool dropped = false;
  int refs = 0;  // handles the user holds, plus one for the database

  ManualCompaction* manual = nullptr;
  RangeDelCache rd_cache;
  std::set<uint64_t> pending_outputs;
  CompactionStats stats[config::kNumLevels];

  const Comparator* user_comparator() const { return icmp.user_comparator(); }
};

class ColumnFamilyHandleImpl : public ColumnFamilyHandle {
 public:
  ColumnFamilyHandleImpl(ColumnFamily* cf, DB* db) : cf_(cf), db_(db) {}
  ~ColumnFamilyHandleImpl() override = default;

  const std::string& GetName() const override { return cf_->name; }
  uint32_t GetID() const override { return cf_->id; }

  ColumnFamily* cf() const { return cf_; }
  DB* db() const { return db_; }

 private:
  ColumnFamily* const cf_;
  DB* const db_;
};

// The directory a family's files live in.
inline std::string ColumnFamilyDir(const std::string& dbname, uint32_t id) {
  if (id == 0) return dbname;
  return dbname + "/cf-" + std::to_string(id);
}

// The FAMILIES file: "<next id>\n" then one "<id> <name>" line per family
// other than the default.
std::string FamiliesFileName(const std::string& dbname);
Status ReadFamilies(Env* env, const std::string& dbname,
                    std::vector<std::pair<uint32_t, std::string>>* families,
                    uint32_t* next_id);
Status WriteFamilies(Env* env, const std::string& dbname,
                     const std::vector<std::pair<uint32_t, std::string>>& families,
                     uint32_t next_id);

}  // namespace leveldb

#endif  // STORAGE_LEVELDB_DB_COLUMN_FAMILY_H_
